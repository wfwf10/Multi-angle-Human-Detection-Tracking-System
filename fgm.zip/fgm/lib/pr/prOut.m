function prOut
% Stop a propmter for function.
%
% History
%   create  -  Feng Zhou (zhfe99@gmail.com), 01-29-2009
%   modify  -  Feng Zhou (zhfe99@gmail.com), 03-02-2012

% variables set in "prSet.m"
global lPr;

% delete
lPr = lPr - 1;
