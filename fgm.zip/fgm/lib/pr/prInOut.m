function prInOut(varargin)
% % Start a propmter for displaying information.
%
% Input
%   varargin  -  object list
%
% History
%   create    -  Feng Zhou (zhfe99@gmail.com), 08-29-2011
%   modify    -  Feng Zhou (zhfe99@gmail.com), 10-09-2011

prIn(varargin{:});
prOut;
