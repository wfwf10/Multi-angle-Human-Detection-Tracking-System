% function i = atoi(a)
% String to integer
%
% Input
%   a       -  string
%
% Output
%   i       -  integer
%
% History
%   create  -  Feng Zhou (zhfe99@gmail.com), 01-29-2009
%   modify  -  Feng Zhou (zhfe99@gmail.com), 10-09-2011
