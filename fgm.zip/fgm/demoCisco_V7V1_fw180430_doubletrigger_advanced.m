multiview=5;

if multiview==7
    load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1_17.mat'); 
    VOB_1_orig = VOB_1;
    load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_2_17.mat'); 
    VOB_2_orig = VOB_2;
    T_7_1 = load('T_7_1.mat');
    T_7_1 = cell2mat(struct2cell(T_7_1));
    %errorframe=-1;
    distancethresold=300;
    savedir='D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1_1771.mat';
end

if multiview==5
    load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1_177117_15.mat'); 
    VOB_1_orig = VOB_1;
    load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_2_177117_15.mat'); 
    VOB_2_orig = VOB_2;
    T_7_1 = load('T_5_1.mat');
    T_7_1 = cell2mat(struct2cell(T_7_1));
    %errorframe=97;
    distancethresold=1000;
    savedir='D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1_177117_1551.mat';
end

for i=1:length(VOB_1)
    for j=1:length(VOB_2)
        if 1
            match_frame=VOB_1(i).occurencehistory(1);
            x1=VOB_1(i).locationhistory(1,1);
            y1=VOB_1(i).locationhistory(1,2);
            V2_index=find(VOB_2(j).occurencehistory()==match_frame);
            x2=VOB_2(j).locationhistory(V2_index,1);
            y2=VOB_2(j).locationhistory(V2_index,2);
            occupyflag=0;
            for k=1:length(VOB_1)
                if (k~=i)&&(VOB_1(k).occurencehistory(1)<=match_frame)&&(VOB_1(k).occurencehistory(end)>=match_frame)
                    if (VOB_1(k).color==VOB_2(j).color)
                        occupyflag=1;
                    end
                end
            end
            location_xy_T = round( homography_transform([y2;x2],T_7_1) );
            if ((location_xy_T(2)-x1)^2+(location_xy_T(1)-y1)^2 < distancethresold)&&(occupyflag==0)%&&(match_frame~=errorframe)
                VOB_1(i).color=VOB_2(j).color;
                %(location_xy_T(2)-x1)^2+(location_xy_T(1)-y1)^2
                %i,j
            end
        end
    end
end

save(savedir,'VOB_1')



