function asg = fgmD_Cisco(KP, KQ, Ct, gphs, par)

% function parameter
nAlp = ps(par, 'nAlp', 101);
nItMa = ps(par, 'nItMa', 100);
nHst = ps(par, 'nHst', 10);
isIp = psY(par, 'ip', 'n');
isDeb = psY(par, 'deb', 'n');
prIn('fgmD', 'nAlp %d, nItMa %d, nHst %d, isIp %d', ...
     nAlp, nItMa, nHst, isIp);

% weight
alps = linspace(0, 1, nAlp);

% store variables
XQ1 = ps(par, 'XQ1', []);
XQ2 = ps(par, 'XQ2', []);
pathDStore_Cisco(KP, KQ, Ct, XQ1, XQ2, gphs, 'path', []);

% path-following
[X, ~, obj, nIts, Xs, objs, objGms, objCons, objVexs, objCavs, useIps, objInss, objIn2ss] = pathDIter(alps, nItMa, nHst, isIp, isDeb, 1, [], 0);

% matching with ground-truth assignment if possible

% store
asg.alg = 'fgmD';
asg.X = X;
asg.obj = full(obj);

% for debug
asg.nIts = nIts;
asg.Xs = Xs;
asg.objs = objs;
asg.objGms = objGms;
asg.objVexs = objVexs;
asg.objCavs = objCavs;
asg.objCons = objCons;
asg.objInss = objInss;
asg.objIn2ss = objIn2ss;
asg.useIps = useIps;

prOut;
