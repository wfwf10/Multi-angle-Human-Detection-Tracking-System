load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1.mat'); 
VOB_1_orig = VOB_1;
load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_2.mat'); 
VOB_2_orig = VOB_2;

match_frame=VOB_1(10).occurencehistory(1);
x1=VOB_1(10).locationhistory(1,1);
y1=VOB_1(10).locationhistory(1,2);
V2_index=find(VOB_2(10).occurencehistory()==match_frame);
x2=VOB_2(10).locationhistory(V2_index,1);
y2=VOB_2(10).locationhistory(V2_index,2);
T_7_1 = load('T_7_1.mat');
T_7_1 = cell2mat(struct2cell(T_7_1));
location_xy_T = round( homography_transform([y2;x2],T_7_1) );
if (location_xy_T(2)-x1)^2+(location_xy_T(1)-y1)^2 < 300
    VOB_1(10).color=VOB_2(10).color;
end
 save('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_dt\VOB_1_71.mat','VOB_1')
