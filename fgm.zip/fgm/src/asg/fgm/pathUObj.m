function [obj, objGm, objVex, objCav] = pathUObj(X, alp)
% Compute objective for the path-following algorithm.
%
% Input
%   X         -  correspondence, n1 x n2
%   alp       -  alpha
%             
% Output      
%   obj       -  J_alpha
%   objGm     -  J_gm
%   objVex    -  J_vex
%   objCav    -  J_cav
%
% History     
%   create    -  Feng Zhou (zhfe99@gmail.com), 01-26-2012
%   modify    -  Feng Zhou (zhfe99@gmail.com), 05-06-2013

% global
global L KQ;
global HH1 HH2 UU VV UUHH VVHH HUH HVH GKGP;
global IndG1 IndG2 IndG1T IndG2T IndH1 IndH2 IndH1T IndH2T;

% trace(L' * (H1' * X * H2) .^ 2);
tmp1 = multTr(L .* multGXH(IndH1T, X, IndH2) .^ 2);
objGm = tmp1;

% trace(U * U' * ((H1' * H1) .* (H1' * X * X' * H1)));
tmp2 = multTr(UU, HH1, multGXH(IndH1T, X * X', IndH1));

% trace(V * V' * ((H2' * H2) .* (H2' * X' * X * H2)));
tmp3 = multTr(VV, HH2, multGXH(IndH2T, X' * X, IndH2));

% convex part
objVex = tmp1 - .5 * tmp2 - .5 * tmp3;

% trace(KQ' * (G1' * X * G2) .^ 2);
tmp1 = multTr(KQ, multGXH(IndG1T, X, IndG2) .^ 2);

% trace((-G1 * KQ * G2' + KP)' * X);
tmp2 = multTr(GKGP, X);

% concave part
objCav = tmp1 + tmp2;

% linear interoplation
obj = (1 - alp) * objVex + alp * objCav;