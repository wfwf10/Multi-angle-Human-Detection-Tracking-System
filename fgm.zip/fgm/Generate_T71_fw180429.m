clear;clc;close all;

Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Multiview\'; 
bg1 = imread(strcat(Images_Directory, 'V1_background.jpg'));
bg7 = imread(strcat(Images_Directory, 'V7_background.jpg'));
I1=rgb2gray(bg1);
I7=rgb2gray(bg7);
%figure;imshow(I1);
%figure;imshow(I7);

pin1=[629,343,751,164];%17,
pin2=[233,313,276,275];%189,
pout1=[705,172,99,327];%669,
pout2=[386,246,563,201];%176,
pin=[pin1;pin2];
pout=[pout1;pout2];

v=homography_solve(pin,pout); %pout,pin for T_7_1, converse for T_1_7
%y = homography_transform(I7, v);
%figure;imshow(y);

%tform = fitgeotrans(pout,pin,'projective');
%I2_to_I1 = imwarp(I2,tform,'OutputView',imref2d(size(I2)));
%figure;subplot(1,2,1);imshow(I2_to_I1);
%subplot(1,2,2);imshow(I1);

%i=4;
%subplot(1,2,1);imshow(I1);hold on;plot(pin1(i),pin2(i),'-o');
%subplot(1,2,2);imshow(I7);hold on;plot(pout1(i),pout2(i),'-o');




