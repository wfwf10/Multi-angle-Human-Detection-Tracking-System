% ===============================================================================================
% Project: Cross-Camera Human Tracking (Cisco)
% Video Lab @ NYU, Tandon School of Engineering
%
% This Program will 
% Input:
% Output: 
%
% Revision History
% 12/12/2016	By Fanyi Duanmu	- Initial Version
% ===============================================================================================

clear; clc; close all;
cd D:\
cd D:\fgm
%cd C:\1Cisco\fgm;

clear variables;
prSet(1);

% User Defined Area - START
% Video Parameters
frame_number = 4015; % 4005
Anchor_index = 1;
Tracking_index = 5;

% Debugging Parameters
IsDebugging = 1;

% User Defined Area - END


for frame_number = 4014
% Load Data
addpath('C:\1Cisco\fgm');
width1 = 768; 
width2 = 720;
height1 = 576;
height2 = 576;
frame1 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Anchor_index),'\frame_', num2str(frame_number),'.jpg'));
frame2 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Tracking_index),'\frame_', num2str(frame_number),'.jpg'));
CNN_Matrix_Directory_Prefix1 = strcat('C:\1Cisco\C1_Cross_View_Translation\Mat', num2str(Anchor_index),'\', num2str(frame_number)); 
CNN_Matrix_Directory_Prefix2 = strcat('C:\1Cisco\C1_Cross_View_Translation\Mat', num2str(Tracking_index),'\', num2str(frame_number)); 
d1 = dir(strcat(CNN_Matrix_Directory_Prefix1,'\*.mat'));
d2 = dir(strcat(CNN_Matrix_Directory_Prefix2,'\*.mat'));

Object_number1 = size(d1,1); Object_number2 = size(d2,1);
xy_coordinate_1 = []; xy_coordinate_2 = [];

for i = 1:Object_number1
	load(strcat(CNN_Matrix_Directory_Prefix1,'\frame_', num2str(frame_number),'_person_obj',num2str(i)));
	vertical_top = max(ceil(bbox(2)),1); 
	vertical_bottom = min(floor(bbox(4)),height1-1);
	horizontal_left = max(ceil(bbox(1)),1);
	horizontal_right = min(floor(bbox(3)),width1-1);	
	x = floor( (horizontal_left + horizontal_right)/2 );
	y = vertical_bottom;
	rcnn1{i} = feature;
	xy_coordinate_1 = [xy_coordinate_1; y x];
	%frame1(vertical_top:vertical_bottom,[horizontal_left horizontal_right],:)=0;
	%frame1([vertical_top vertical_bottom],horizontal_left:horizontal_right,:)=0;
    Anchor_Obj_Fig{i} = frame1(vertical_top:vertical_bottom,horizontal_left:horizontal_right,:);
	clear bbox; clear obj_image; clear score; clear feature;
end
for i = 1:Object_number2
	load(strcat(CNN_Matrix_Directory_Prefix2,'\frame_', num2str(frame_number),'_person_obj',num2str(i)));
	vertical_top = max(ceil(bbox(2)),1); 
	vertical_bottom = min(floor(bbox(4)),height2-1);
	horizontal_left = max(ceil(bbox(1)),1);
	horizontal_right = min(floor(bbox(3)),width2-1);	
	x = floor( (horizontal_left + horizontal_right)/2 );
	y = vertical_bottom;
	rcnn2{i} = feature;
	xy_coordinate_2 = [xy_coordinate_2; y x];
	%frame2(vertical_top:vertical_bottom,[horizontal_left horizontal_right],:)=0;
	%frame2([vertical_top vertical_bottom],horizontal_left:horizontal_right,:)=0;
    Tracking_Obj_Fig{i} = frame2(vertical_top:vertical_bottom,horizontal_left:horizontal_right,:);
	clear bbox; clear obj_image; clear score; clear feature;
end

% Load Transformation Matrices
T_5_1 = load('T_5_1.mat');
T_5_1 = cell2mat(struct2cell(T_5_1));
frame2_T = imagehomog(frame2, T_5_1, 'm');

parFgmA = st('nItMa', 100, 'nAlp', 101, 'deb', 'n', 'ip', 'n', 'lamQ', .5); % GM parameters (default)
egDen = 0.5;
parGph = st('link', 'full', 'val', egDen);

if 0
	figure; imshow(frame1); title('Anchor Frame');
	figure; imshow(frame2); title('Tracking Frame');
	figure; imshow(frame2_T); title('Transformed Tracking Frame');
end

Pt1 = xy_coordinate_1';	% firstly row then column
%% Pt1_backup = xy_coordinate_1';
Pt2_backup = xy_coordinate_2';
Pt2_swap(1,:) = Pt2_backup(2,:); Pt2_swap(2,:) = Pt2_backup(1,:);
xy_coordinate_2_T = round( homography_transform(Pt2_swap,T_5_1) ); % firstly column then row
Pt2(1,:) = xy_coordinate_2_T(2,:);
Pt2(2,:) = xy_coordinate_2_T(1,:);
%%Pt1(1,:) = Pt1_backup(2,:);
%%Pt1(2,:) = Pt1_backup(1,:);

if IsDebugging
    %figure; imshow(frame1);
    %figure; imshow(frame2);
	figure;
	subplot(2,3,1); imshow(frame1); title('Anchor Frame');
	subplot(2,3,2); imshow(frame2); title('Tracking Frame');
	subplot(2,3,3); imshow(frame2_T); title('Transformed Tracking Frame');
	subplot(2,3,4); plot(Pt1(2,:), height1-Pt1(1,:),'o'); title('Original Distribution from Anchor'); axis([1 width1 1 height1]);
	subplot(2,3,5); plot(Pt2_backup(2,:), height2-Pt2_backup(1,:),'o'); title('Original Distribution from Tracking'); axis([1 width2 1 height2]);
	subplot(2,3,6); plot(Pt2(2,:), height2-Pt2(1,:),'x'); title('Transformed Distribution from Tracking'); axis([1 width2 1 height2]);
end

%gphs{1} = newGphU_Cisco(Pt1, parGph);
%gphs{2} = newGphU_Cisco(Pt2, parGph);
gphs{1} = newGphA(Pt1, parGph);
gphs{2} = newGphA(Pt2, parGph);

% In graph structure, G and H are automatically populated
% Eg, vis: node connection (i.e., edge) definition
% G, H: edge-node / node-edge relationship

% 20161215
load('w2c.mat');
for j = 1:length(Anchor_Obj_Fig)
    Anchor_Obj_Fig_Patch = double(Anchor_Obj_Fig{j});
    Anchor_Obj_Fig_Patch_Color_Mapped = im2c(Anchor_Obj_Fig_Patch,w2c,-1);
    Anchor_Obj_Fig_Post{j} = Anchor_Obj_Fig_Patch_Color_Mapped;
    %HS-RGB
    Anchor_Obj_Fig_Patch_R = Anchor_Obj_Fig_Patch(:,:,1);
    Anchor_Obj_Fig_Patch_G = Anchor_Obj_Fig_Patch(:,:,2);
    Anchor_Obj_Fig_Patch_B = Anchor_Obj_Fig_Patch(:,:,3);
    Anchor_Obj_Fig_Patch_HSV = rgb2hsv(Anchor_Obj_Fig_Patch);
    Anchor_Obj_Fig_Patch_H = Anchor_Obj_Fig_Patch_HSV(:,:,1);
    Anchor_Obj_Fig_Patch_S = Anchor_Obj_Fig_Patch_HSV(:,:,2);
    Anchor_Obj_Fig_Patch_R_hist = imhist(Anchor_Obj_Fig_Patch_R, 6);
    Anchor_Obj_Fig_Patch_G_hist = imhist(Anchor_Obj_Fig_Patch_G, 6);
    Anchor_Obj_Fig_Patch_B_hist = imhist(Anchor_Obj_Fig_Patch_B, 6);
    Anchor_Obj_Fig_Patch_H_hist = imhist(Anchor_Obj_Fig_Patch_H, 6);
    Anchor_Obj_Fig_Patch_S_hist = imhist(Anchor_Obj_Fig_Patch_S, 6);
    Anchor_Obj_Fig_HSRGB{j} = [Anchor_Obj_Fig_Patch_R_hist' Anchor_Obj_Fig_Patch_G_hist' Anchor_Obj_Fig_Patch_B_hist' Anchor_Obj_Fig_Patch_H_hist' Anchor_Obj_Fig_Patch_S_hist'];
    %HOG
    [HOGVector,hogVisualization] = extractHOGFeatures(Anchor_Obj_Fig_Patch);
    Anchor_Obj_Fig_HOG{j} = HOGVector;
    Anchor_Obj_Fig_HOG_Visual{j} = hogVisualization;
end    
Split_Factor = 0;   % Not Divide
for k = 1:length(Anchor_Obj_Fig)
    [Row Col dummy] = size(Anchor_Obj_Fig_Post{k});
    Anchor_Obj_Fig_Patch = double(Anchor_Obj_Fig_Post{k});
    if ~Split_Factor
        global_hist = zeros(1,11);
        for i = 1:Row
            for j = 1:Col
                if( Anchor_Obj_Fig_Patch(i,j,1)==0 & Anchor_Obj_Fig_Patch(i,j,2)==0 && Anchor_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(1) = global_hist(1) + 1;    % black - 1
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==0 & Anchor_Obj_Fig_Patch(i,j,2)==0 && Anchor_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(2) = global_hist(2) + 1;    % blue - 2          
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255*0.5 & Anchor_Obj_Fig_Patch(i,j,2)==255*0.4 && Anchor_Obj_Fig_Patch(i,j,3)==255*0.25 )
                    global_hist(3) = global_hist(3) + 1;    % brown - 3
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255*0.5 & Anchor_Obj_Fig_Patch(i,j,2)==255*0.5 && Anchor_Obj_Fig_Patch(i,j,3)==255*0.5 )
                    global_hist(4) = global_hist(4) + 1;    % gray - 4
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==0 & Anchor_Obj_Fig_Patch(i,j,2)==255 && Anchor_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(5) = global_hist(5) + 1;    % green - 5
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==255*0.8 && Anchor_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(6) = global_hist(6) + 1;    % orange - 6
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==255*0.5 && Anchor_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(7) = global_hist(7) + 1;    % pink - 7
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==0 && Anchor_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(8) = global_hist(8) + 1;    % purple - 8
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==0 && Anchor_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(9) = global_hist(9) + 1;    % red - 9  
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==255 && Anchor_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(10) = global_hist(10) + 1;    % white - 10 
                elseif( Anchor_Obj_Fig_Patch(i,j,1)==255 & Anchor_Obj_Fig_Patch(i,j,2)==255 && Anchor_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(11) = global_hist(11) + 1;    % yellow - 11                     
                end
            end
        end
        Anchor_Obj_Fig_hist{k} = global_hist;
    else
        ;
    end
end
if IsDebugging & 0
    figure;
    for j = 1:length(Anchor_Obj_Fig)
        subplot(5,length(Anchor_Obj_Fig),j); imshow(uint8(Anchor_Obj_Fig{j}));
        subplot(5,length(Anchor_Obj_Fig),j+length(Anchor_Obj_Fig));imshow(uint8(Anchor_Obj_Fig_Post{j}));
        subplot(5,length(Anchor_Obj_Fig),j+2*length(Anchor_Obj_Fig));bar(Anchor_Obj_Fig_hist{j}/Row/Col);
        subplot(5,length(Anchor_Obj_Fig),j+3*length(Anchor_Obj_Fig));bar(Anchor_Obj_Fig_HSRGB{j}/Row/Col);
        subplot(5,length(Anchor_Obj_Fig),j+4*length(Anchor_Obj_Fig));plot(Anchor_Obj_Fig_HOG_Visual{j});
    end
end

for j = 1:length(Tracking_Obj_Fig)
    Tracking_Obj_Fig_Patch = double(Tracking_Obj_Fig{j});
    Tracking_Obj_Fig_Patch_Color_Mapped = im2c(Tracking_Obj_Fig_Patch,w2c,-1);
    Tracking_Obj_Fig_Post{j} = Tracking_Obj_Fig_Patch_Color_Mapped;
    % HS-RGB
    Tracking_Obj_Fig_Patch_R = Tracking_Obj_Fig_Patch(:,:,1);
    Tracking_Obj_Fig_Patch_G = Tracking_Obj_Fig_Patch(:,:,2);
    Tracking_Obj_Fig_Patch_B = Tracking_Obj_Fig_Patch(:,:,3);
    Tracking_Obj_Fig_Patch_HSV = rgb2hsv(Tracking_Obj_Fig_Patch);
    Tracking_Obj_Fig_Patch_H = Tracking_Obj_Fig_Patch_HSV(:,:,1);
    Tracking_Obj_Fig_Patch_S = Tracking_Obj_Fig_Patch_HSV(:,:,2);
    Tracking_Obj_Fig_Patch_R_hist = imhist(Tracking_Obj_Fig_Patch_R, 6);
    Tracking_Obj_Fig_Patch_G_hist = imhist(Tracking_Obj_Fig_Patch_G, 6);
    Tracking_Obj_Fig_Patch_B_hist = imhist(Tracking_Obj_Fig_Patch_B, 6);
    Tracking_Obj_Fig_Patch_H_hist = imhist(Tracking_Obj_Fig_Patch_H, 6);
    Tracking_Obj_Fig_Patch_S_hist = imhist(Tracking_Obj_Fig_Patch_S, 6);
    Tracking_Obj_Fig_HSRGB{j} = [Tracking_Obj_Fig_Patch_R_hist' Tracking_Obj_Fig_Patch_G_hist' Tracking_Obj_Fig_Patch_B_hist' Tracking_Obj_Fig_Patch_H_hist' Tracking_Obj_Fig_Patch_S_hist'];
    % HOG
    [HOGVector,hogVisualization] = extractHOGFeatures(Tracking_Obj_Fig_Patch);
    Tracking_Obj_Fig_HOG{j} = HOGVector;
    Tracking_Obj_Fig_HOG_Visual{j} = hogVisualization;
end    
Split_Factor = 0;   % Not Divide
for k = 1:length(Tracking_Obj_Fig)
    [Row Col dummy] = size(Tracking_Obj_Fig_Post{k});
    Tracking_Obj_Fig_Patch = double(Tracking_Obj_Fig_Post{k});
    if ~Split_Factor
        global_hist = zeros(1,11);
        for i = 1:Row
            for j = 1:Col
                if( Tracking_Obj_Fig_Patch(i,j,1)==0 & Tracking_Obj_Fig_Patch(i,j,2)==0 && Tracking_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(1) = global_hist(1) + 1;    % black - 1
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==0 & Tracking_Obj_Fig_Patch(i,j,2)==0 && Tracking_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(2) = global_hist(2) + 1;    % blue - 2          
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255*0.5 & Tracking_Obj_Fig_Patch(i,j,2)==255*0.4 && Tracking_Obj_Fig_Patch(i,j,3)==255*0.25 )
                    global_hist(3) = global_hist(3) + 1;    % brown - 3
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255*0.5 & Tracking_Obj_Fig_Patch(i,j,2)==255*0.5 && Tracking_Obj_Fig_Patch(i,j,3)==255*0.5 )
                    global_hist(4) = global_hist(4) + 1;    % gray - 4
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==0 & Tracking_Obj_Fig_Patch(i,j,2)==255 && Tracking_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(5) = global_hist(5) + 1;    % green - 5
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==255*0.8 && Tracking_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(6) = global_hist(6) + 1;    % orange - 6
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==255*0.5 && Tracking_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(7) = global_hist(7) + 1;    % pink - 7
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==0 && Tracking_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(8) = global_hist(8) + 1;    % purple - 8
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==0 && Tracking_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(9) = global_hist(9) + 1;    % red - 9  
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==255 && Tracking_Obj_Fig_Patch(i,j,3)==255 )
                    global_hist(10) = global_hist(10) + 1;    % white - 10 
                elseif( Tracking_Obj_Fig_Patch(i,j,1)==255 & Tracking_Obj_Fig_Patch(i,j,2)==255 && Tracking_Obj_Fig_Patch(i,j,3)==0 )
                    global_hist(11) = global_hist(11) + 1;    % yellow - 11                     
                end
            end
        end
        Tracking_Obj_Fig_hist{k} = global_hist;
    end
end
if IsDebugging & 0
    figure;
    for j = 1:length(Tracking_Obj_Fig)
        subplot(5,length(Tracking_Obj_Fig),j); imshow(uint8(Tracking_Obj_Fig{j}));
        subplot(5,length(Tracking_Obj_Fig),j+length(Tracking_Obj_Fig));imshow(uint8(Tracking_Obj_Fig_Post{j}));
        subplot(5,length(Tracking_Obj_Fig),j+2*length(Tracking_Obj_Fig));bar(Tracking_Obj_Fig_hist{j}/Row/Col);
        subplot(5,length(Tracking_Obj_Fig),j+3*length(Tracking_Obj_Fig));bar(Tracking_Obj_Fig_HSRGB{j}/Row/Col);
        subplot(5,length(Tracking_Obj_Fig),j+4*length(Tracking_Obj_Fig));plot(Tracking_Obj_Fig_HOG_Visual{j});
    end
end

% Construct KP, KQ myself
Pt2 = Pt2';
for i = 1:Object_number1
	for j = 1:Object_number2
		% KP(i,j) = 1/(sqrt( sum(( rcnn1{i}-rcnn2{j} ).^2) ) + 1e-5) * exp(-(    sqrt( sum((Anchor_Obj_Fig_HSRGB{i} - Tracking_Obj_Fig_HSRGB{j}).^2) )  ));
        % KP(i,j) = 0; %% 12/15
		dx1(i) = xy_coordinate_1(i,1);
		dx2(j) = Pt2(j,1);
		dy1(i) = xy_coordinate_1(i,2);
		dy2(j) = Pt2(j,2);
		KP(i,j) = exp(- abs(dx1(i)-dx2(j)) - abs(dy1(i)-dy2(j)) ); % 2016/12/18
        % KP(i,j) = 1/(sqrt( sum(( rcnn1{i}-rcnn2{j} ).^2) ) + 1e-5) * exp(- abs(dx1(i)-dx2(j)) - abs(dy1(i)-dy2(j)) ); % 2016/12/18
        KP(i,j) = exp(- abs(dx1(i)-dx2(j)) - abs(dy1(i)-dy2(j)) ); % 2016/12/19
        KP_RCNN(i,j) = 1/(sqrt( sum(( rcnn1{i}-rcnn2{j} ).^2) ) + 1e-5);
	end
end
KP = double(KP);
clear dx1; clear dx2; clear dy1; clear dy2;
    
temp1 = [];
%% Pt1 = Pt1';
for i = 1:length(gphs{1}.Eg)
	dst1(i) = sqrt( sum( ( xy_coordinate_1(gphs{1}.Eg(1,i),:) - xy_coordinate_1(gphs{1}.Eg(2,i),:)).^2 ) );
    dx1(i) = xy_coordinate_1(gphs{1}.Eg(1,i),1) - xy_coordinate_1(gphs{1}.Eg(2,i),1);
    dy1(i) = xy_coordinate_1(gphs{1}.Eg(1,i),2) - xy_coordinate_1(gphs{1}.Eg(2,i),2);
	temp1 = [temp1; dst1(i)];
end
%dst1 = dst1 / sqrt(var(temp1));

temp2 = [];
for i = 1:length(gphs{2}.Eg)
	% dst2(i) = sqrt( sum( ( xy_coordinate_2(gphs{2}.Eg(1,i),:) - xy_coordinate_2(gphs{2}.Eg(2,i),:)).^2 ) );
	dst2(i) = sqrt( sum( ( Pt2(gphs{2}.Eg(1,i),:) - Pt2(gphs{2}.Eg(2,i),:)).^2 ) );
    dx2(i) = Pt2(gphs{1}.Eg(1,i),1) - Pt2(gphs{2}.Eg(2,i),1);
    dy2(i) = Pt2(gphs{1}.Eg(1,i),2) - Pt2(gphs{2}.Eg(2,i),2);
	temp2 = [temp2; dst2(i)];
end
%dst2 = dst2 / sqrt(var(temp2));
dst1 = dst1/sqrt(var([temp1' temp2'])); %%%%1207
dst2 = dst2/sqrt(var([temp1' temp2'])); %%%%1207

temp = [];
for i = 1:length(gphs{1}.Eg)
	for j = 1:length(gphs{2}.Eg)
		% 1215 KQ(i,j) = exp( -abs( dst1(i) - dst2(j) ) ); %% 1215
        KQ(i,j) = exp( -abs(dx1(i)-dx2(j)) -abs(dy1(i)-dy2(j)) );
		temp = [temp; KQ(i,j)];	
	end
end

KQ = double(KQ);
Ct = ones(size(KP));
asgFgmD = fgmD_Cisco(KP, KQ, Ct, gphs, parFgmA);

bb_color{1} = [255 127 80];		% ɺ��
bb_color{2} = [255 0 0];		% ��ɫ
bb_color{3} = [255 255 0];		% ��ɫ
bb_color{4} = [0 0 255];		% ��ɫ
bb_color{5} = [0 255 0];		% ��ɫ 
bb_color{6} = [252 230 201];	% ����
bb_color{7} = [128 138 135];	% ���
bb_color{8} = [0 0 0];			% ��ɫ
bb_color{9} = [255 192 203];	% �ۺ�
bb_color{10} = [250 128 114];	% �Ⱥ�

% Display Results
output_frame1 = frame1;
output_frame2 = frame2;
R = 5;
for j = 1:Object_number1
	if ~isempty( find( asgFgmD.X(j,:)==1) )
		matching_object_idx(j) = find( asgFgmD.X(j,:)==1);
		output_frame1(Pt1(1,j)-R:Pt1(1,j)+R,Pt1(2,j)-R:Pt1(2,j)+R,1) = bb_color{j+1}(1);
		output_frame1(Pt1(1,j)-R:Pt1(1,j)+R,Pt1(2,j)-R:Pt1(2,j)+R,2) = bb_color{j+1}(2);
		output_frame1(Pt1(1,j)-R:Pt1(1,j)+R,Pt1(2,j)-R:Pt1(2,j)+R,3) = bb_color{j+1}(3);
		output_frame2(Pt2_backup(1,matching_object_idx(j))-R:Pt2_backup(1,matching_object_idx(j))+R,Pt2_backup(2,matching_object_idx(j))-R:Pt2_backup(2,matching_object_idx(j))+R,1) = bb_color{j+1}(1);
		output_frame2(Pt2_backup(1,matching_object_idx(j))-R:Pt2_backup(1,matching_object_idx(j))+R,Pt2_backup(2,matching_object_idx(j))-R:Pt2_backup(2,matching_object_idx(j))+R,2) = bb_color{j+1}(2);
		output_frame2(Pt2_backup(1,matching_object_idx(j))-R:Pt2_backup(1,matching_object_idx(j))+R,Pt2_backup(2,matching_object_idx(j))-R:Pt2_backup(2,matching_object_idx(j))+R,3) = bb_color{j+1}(3);
	end  
end

if IsDebugging
	figure; 
	subplot(1,2,1); imshow(output_frame1,[]);title('Anchor Frame (marked)');
	subplot(1,2,2); imshow(output_frame2,[]);title('Tracking Frame (marked)');
end

end %%---


% 2017/01/03
frame_number = 15;
width1 = 768; %%--
height1 = 576; %%--
load location_time_info_view1_f1_f15;
location_time_info_view1 = location_time_info; clear location_time_info; 
figure;
for i = 1:length(location_time_info_view1)
    location_time_info_view1_processed = zeros(frame_number,3); 
    location_time_info_view1_processed(:,1) = 1:frame_number;
    location_time_info_view1_temp = location_time_info_view1{i};
    index = location_time_info_view1_temp(:,1);
    location_time_info_view1_processed(index,:) = location_time_info_view1_temp;
    location_time_info_view1_processed_output{i} = location_time_info_view1_processed;
    disp_temp_buffer = zeros(height1, width1);
    for j = 1:length(location_time_info_view1_processed_output{i})
        yy = round( location_time_info_view1_processed(j,2) );
        xx = round( location_time_info_view1_processed(j,3) );
        if location_time_info_view1_processed(j,2)~=0 & location_time_info_view1_processed(j,3)~=0
            disp_temp_buffer(yy-5:yy+5,xx-5:xx+5) = 255;
        end
    end
    subplot(1,length(location_time_info_view1),i);imshow(disp_temp_buffer);
end

width2 = 720; %%--
height2 = 576; %%--
T_5_1 = load('T_5_1.mat'); %%--
T_5_1 = cell2mat(struct2cell(T_5_1)); %%--
load location_time_info_view5_f1_f15;
location_time_info_view5 = location_time_info; clear location_time_info;

figure;
for i = 1:length(location_time_info_view5)
    location_time_info_view5_processed = zeros(frame_number,3); 
    location_time_info_view5_processed(:,1) = 1:frame_number;
    location_time_info_view5_temp = location_time_info_view5{i};    
    index = location_time_info_view5_temp(:,1);
    location_time_info_view5_processed(index,:) = location_time_info_view5_temp; 
    
    location_xy = location_time_info_view5_processed(:,2:3);
    Pt2_backup_seq = location_xy';
    Pt2_swap_seq(1,:) = Pt2_backup_seq(2,:); 
    Pt2_swap_seq(2,:) = Pt2_backup_seq(1,:);
    location_xy_T = round( homography_transform(Pt2_swap_seq,T_5_1) );
    Pt2_seq(1,:) = location_xy_T(2,:);
    Pt2_seq(2,:) = location_xy_T(1,:);    
    location_time_info_view5_processed_output{i} = [location_time_info_view5_processed(:,1) Pt2_seq'];
    disp_temp_buffer1 = zeros(height2, width2);   
    disp_temp_buffer2 = zeros(height2, width2);
    for j = 1:length(location_time_info_view5_processed_output{i})
        yy = round( location_time_info_view5_processed_output{i}(j,2) );
        xx = round( location_time_info_view5_processed_output{i}(j,3) );
        yy2 = round( location_time_info_view5_processed(j,2) );
        xx2 = round( location_time_info_view5_processed(j,3) );
        if location_time_info_view5_processed_output{i}(j,2)>0 & location_time_info_view5_processed_output{i}(j,3)>0
            disp_temp_buffer2(yy-5:yy+5,xx-5:xx+5) = 255;
            disp_temp_buffer1(yy2-5:yy2+5,xx2-5:xx2+5) = 255;
        end
    end
    subplot(2,length(location_time_info_view5),i); imshow(disp_temp_buffer1); title('Original');
    subplot(2,length(location_time_info_view5),i+length(location_time_info_view5)); imshow(disp_temp_buffer2);title('Transformed');
end



clear x1; clear x2; clear y1; clear y2; 
for i = 1:length(location_time_info_view1_processed_output)
	for j = 1:length(location_time_info_view5_processed_output)
        ratio_mse_x = 0; ratio_mse_y = 0;
        x1{i} = location_time_info_view1_processed_output{i}(:,2);
        y1{i} = location_time_info_view1_processed_output{i}(:,3);
        x2{j} = location_time_info_view5_processed_output{j}(:,2);
        y2{j} = location_time_info_view5_processed_output{j}(:,3);
        counter = 0;
        for k = 1:frame_number
            if( (x1{i}(k)) ~=0 & (x2{j}(k)) ~=0 & (y1{i}(k))~=0 & (y2{j}(k)) ~=0)  % the qualified entries to be compared
            	counter = counter + 1;
                ratio_mse_x = ratio_mse_x + ( sum( ( x1{i}(k) - x2{j}(k)).^2 ) );
                ratio_mse_y = ratio_mse_y + ( sum( ( y1{i}(k) - y2{j}(k)).^2 ) );

            end
        end
        %ratio_mse_x
        %ratio_mse_y
        %counter
        KP(i,j) = exp(- (sqrt(ratio_mse_x+ratio_mse_y)/counter) );     
        KPP(i,j) = exp(- ((ratio_mse_x+ratio_mse_y)/counter) );
        KPPP(i,j) = 1/(sqrt((ratio_mse_x+ratio_mse_y))/counter + 1e-10);
	end
end
KP_backup = double(KP); KP_temp = KP;
KPPP_backup = double(KPPP); KPPP_temp = KPPP;

parFgmA_temporal = st('nItMa', 100, 'nAlp', 101, 'deb', 'n', 'ip', 'n', 'lamQ', .5);
parGph_temporal = st('link', 'full', 'val', 0.5);
for t = 1:length(location_time_info_view1_processed_output)
        Pt1_temporal(1:frame_number,t) = round(x1{t}(:));
        Pt1_temporal(1+frame_number:2*frame_number,t) = round(y1{t}(:));
end 
for t = 1:length(location_time_info_view5_processed_output)
        Pt2_temporal(1:frame_number,t) = round(x2{t}(:));
        Pt2_temporal(1+frame_number:2*frame_number,t) = round(y2{t}(:));
end
lookup_2bd = [Pt1_temporal Pt2_temporal]; %%--0112
    
gphs_temporal{1} = newGphA(Pt1_temporal, parGph_temporal);
gphs_temporal{2} = newGphA(Pt2_temporal, parGph_temporal);

P1 = combntns(length(location_time_info_view1_processed_output),2) * 2; % bi-directional
P2 = combntns(length(location_time_info_view5_processed_output),2) * 2; % bi-directional
KQ_temporal = zeros(P1,P2);
KP_temporal = KP;
Ct_temporal = ones(size(KP_temporal));
asgFgmD_temporal = fgmD_Cisco(KP_temporal, KQ_temporal, Ct_temporal, gphs_temporal, parFgmA_temporal);



% Display Results
R = 5; % Display Square Marker Radius
frame1 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Anchor_index),'\frame_', num2str(4000),'.jpg')); output_frame1 = frame1;
frame2 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Tracking_index),'\frame_', num2str(4000),'.jpg')); output_frame2 = frame2; output_frame3 = frame2;
[Row1 Col1 dummy] = size(frame1);
[Row2 Col2 dummy] = size(frame2);
combine_RGB = zeros(max(Row1,Row2),Col1+Col2,3,frame_number);

%??
myObj = VideoWriter(strcat('cross_view_15.mp4'),'MPEG-4');
myObj.FrameRate = 10;
writerObj.FrameRate = 1;
open(myObj);
    
for f = 1:frame_number
    frame1 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Anchor_index),'\frame_', num2str(f+4000),'.jpg')); output_frame1 = frame1;
    frame2 = imread(strcat('C:\1Cisco\C1_Cross_View_Translation\PET', num2str(Tracking_index),'\frame_', num2str(f+4000),'.jpg')); output_frame2 = frame2; output_frame3 = frame2;
    c_index = 1;
    for j = 1:max(length(location_time_info_view1_processed_output),length(location_time_info_view5_processed_output)) % assuming global/ground view always has more objects
        if ~isempty( find( asgFgmD_temporal.X(j,:)==1) )
            matching_object_idx = find( asgFgmD_temporal.X(j,:)==1); % index in tracking view
            % Need to modify
            if Pt1_temporal(f,j)~=0 & Pt1_temporal(f+frame_number,j)~=0
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,1) = bb_color{c_index}(1);
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,2) = bb_color{c_index}(2);
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,3) = bb_color{c_index}(3);
            end
            %output_frame3(Pt2_temporal(1,matching_object_idx)-R:Pt2_temporal(1,matching_object_idx)+R,Pt2_temporal(1+frame_number,matching_object_idx)-R:Pt2_temporal(1+frame_number,matching_object_idx)+R,1) = bb_color{c_index}(1);
            %output_frame3(Pt2_temporal(1,matching_object_idx)-R:Pt2_temporal(1,matching_object_idx)+R,Pt2_temporal(1+frame_number,matching_object_idx)-R:Pt2_temporal(1+frame_number,matching_object_idx)+R,2) = bb_color{c_index}(2);
            %output_frame3(Pt2_temporal(1,matching_object_idx)-R:Pt2_temporal(1,matching_object_idx)+R,Pt2_temporal(1+frame_number,matching_object_idx)-R:Pt2_temporal(1+frame_number,matching_object_idx)+R,3) = bb_color{c_index}(3);
            output_frame2(round(location_time_info_view5{matching_object_idx}(f,2))-R:round(location_time_info_view5{matching_object_idx}(f,2))+R,round(location_time_info_view5{matching_object_idx}(f,3))-R:round(location_time_info_view5{matching_object_idx}(f,3))+R,1) = bb_color{c_index}(1);
            output_frame2(round(location_time_info_view5{matching_object_idx}(f,2))-R:round(location_time_info_view5{matching_object_idx}(f,2))+R,round(location_time_info_view5{matching_object_idx}(f,3))-R:round(location_time_info_view5{matching_object_idx}(f,3))+R,2) = bb_color{c_index}(2);
            output_frame2(round(location_time_info_view5{matching_object_idx}(f,2))-R:round(location_time_info_view5{matching_object_idx}(f,2))+R,round(location_time_info_view5{matching_object_idx}(f,3))-R:round(location_time_info_view5{matching_object_idx}(f,3))+R,3) = bb_color{c_index}(3);
            c_index = c_index + 1;
        else % Only draw in one view with more objects
            if Pt1_temporal(f,j)~=0 & Pt1_temporal(f+frame_number,j)~=0
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,1) = bb_color{c_index}(1);
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,2) = bb_color{c_index}(2);
                output_frame1(Pt1_temporal(f,j)-R:Pt1_temporal(f,j)+R,Pt1_temporal(f+frame_number,j)-R:Pt1_temporal(f+frame_number,j)+R,3) = bb_color{c_index}(3); 
            end
            c_index = c_index + 1;
        end
    end
    combine_RGB(1:Row1,1:Col1,1,f) = output_frame1(:,:,1);combine_RGB(1:Row1,1:Col1,2,f) = output_frame1(:,:,2);combine_RGB(1:Row1,1:Col1,3,f) = output_frame1(:,:,3); %--figure;imshow(uint8(combine_RGB(:,:,:,1)),[]);
    combine_RGB(1:Row2,Col1+1:Col1+Col2,1,f) = output_frame2(:,:,1);combine_RGB(1:Row2,Col1+1:Col1+Col2,2,f) = output_frame2(:,:,2);combine_RGB(1:Row2,Col1+1:Col1+Col2,3,f) = output_frame2(:,:,3); %--figure;imshow(uint8(combine_RGB(:,:,:,1)),[]);
    
    if IsDebugging
        %figure; 
        %subplot(1,2,1); imshow(output_frame1,[]);title('Anchor Frame (marked)');
        %subplot(1,2,2); imshow(output_frame2,[]);title('Tracking Frame (marked)');
        figure; imshow(uint8(combine_RGB(:,:,:,f)),[]);
    end
	writeVideo(myObj,uint8(combine_RGB(:,:,:,f))); 
end
close(myObj);