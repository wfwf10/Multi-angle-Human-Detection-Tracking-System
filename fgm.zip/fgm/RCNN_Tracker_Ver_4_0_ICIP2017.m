% ===============================================================================================
% Multi-angle Human Tracking and Summarization System
% Sponsored by Cisco Inc.
% Video Lab @ New York University, Tandon School of Engineering
%
% This Program will ...
%
% Revision History
% 07/01/2016	By Fanyi Duanmu - Initial Version
% 07/08/2016    By Fanyi Duanmu - Added more colors, debugging traces
% 07/18/2016    By Fanyi Duanmu - Fixed Color Competition Problem (S1 release)
% 08/01/2016    By Fanyi Duanmu - Extended with representative frame
% 08/08/2016    By Fanyi Duanmu - Color Usage Re-ordering and bug-fixes
% 08/09/2016    By Fanyi Duanmu - Added New Color (S2 release)
% 08/17/2016	By Fanyi Duanmu - Bugfixes and Additional Fields introduction (S3 release)
% 08/18/2016	By Fanyi Duanmu - Color Table Expansion
% 01/23/2017    By Fanyi Duanmu - ICIP2017 Simulation (S4 release)
% 02/04/2017    By Fanyi Duanmu - Color Expansion
% 02/05/2017    By Fanyi Duanmu - Added View 7
% 02/07/2017    By Fanyi Duanmu - Distance Modification
% 04/16/2017    By Fanyi Duanmu - Added Profiler and Timer
% ===============================================================================================

clear;clc;close all;

%==========================================================================================%
% User Defined Area - START

% General Info
frame_number = 100;
simulation_date = '20170207';
View = 1;
UseSmallColorPool = 1;

if View==1
	width = 768; height = 576; 
	RCNN_Info_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\RCNN_Per_Frame_V1\'; 
    %fw 'D:\Software\MATLAB\image_processing_project_fgm\fgm\VOB_1.mat'  %'C:\1Cisco\RCNN_Per_Frame_V1\'
	Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Dataset\PET\View_001\'; 
    %fw C:\1Cisco\Dataset\PET\View_001\
	Temporal_Distance_Threshold = 2; %fwfw 5
    IOU_Threshold = 0.3;             %fwfw 0.3
elseif View==5
	width = 720; height = 576;
	RCNN_Info_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\RCNN_Per_Frame_V5\'; 
    %fw 'C:\1Cisco\RCNN_Per_Frame_V5\'
	Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Dataset\PET\View_005\'; 
    %fw C:\1Cisco\Dataset\PET\View_005\
	Temporal_Distance_Threshold = 4; %fwfw 10
    IOU_Threshold = 0.5;             %fwfw 0.3
elseif View==7
    width = 720; height = 576;
    RCNN_Info_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\RCNN_Per_Frame_V7\'; 
    %fw 'C:\1Cisco\RCNN_Per_Frame_V7\'
    Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Dataset\PET\View_007\'; 
    %fw C:\1Cisco\Dataset\PET\View_007\
    Temporal_Distance_Threshold = 2; %fwfw 20
    IOU_Threshold = 0.5;             %fwfw 0.4
end	

output_video_file_name_prep = strcat('PET','_',simulation_date);

% RCNN Info Loading
RCNN_Info_Mat_Prefix = 'frame_';
RCNN_Info_Mat_suffix = '_person_obj';

% Image Loading
Image_Prefix = 'frame_';
Image_Start_Number_Offset = 4000-1;

% Control Flag
IsDebugging = 0;
ShowProcessingImage = 0;
Write2MP4 = 0;
Write2JPG = 1;
if Write2MP4
	output_video_file_name = output_video_file_name_prep;
end
PlotTrajectory = 0;
IntraViewGM_Enabled = 1;
SaveTracklets = 0;
PostProcessing = 1;

% User Defined Area - END
%==========================================================================================%
% Hard-coded Color Definition
if UseSmallColorPool
    bb_color{1} = [0 0 0];		
    bb_color{2} = [255 0 0];	
    bb_color{3} = [255 255 0];	
    bb_color{4} = [0 0 255];	
    bb_color{5} = [0 255 0];	
    bb_color{6} = [252 230 201];
    bb_color{7} = [128 138 135];
    bb_color{8} = [255 127 80];	
    bb_color{9} = [255 192 203];
    bb_color{10} = [250 128 114];
    bb_color{11} = [135 38 87];	
    bb_color{12} = [255 0 255];	
    bb_color{13} = [128 128 105];
    bb_color{14} = [255 97 0];	
    bb_color{15} = [128 42 42];	
    bb_color{16} = [250 235 215];
    bb_color{17} = [51 161 201];
    bb_color{18} = [0 199 140];	
    bb_color{19} = [221 160 221];
    bb_color{20} = [255 235 205];
    bb_color{21} = [0 255 127];	
    bb_color{22} = [160 32 240];
    bb_color{23} = [0 255 255];	
    bb_color{24} = [255 255 255];
    bb_color{25} = [34 139 34];

else
    % Color Expansion
    color_stepsize = 64;
    color_entry_number = 1;
    for R = 0:color_stepsize:255
        for	G = 0:color_stepsize:255
            for	B = 0:color_stepsize:255
                bb_color{color_entry_number} = [R G B];
                color_entry_number = color_entry_number + 1;
            end
        end
    end
end

% Create Display Buffer
image_buffer = zeros(height, width, 3, frame_number);

% Load Images
for i = 1:frame_number
    frame_name=num2str(i-1,'%04d'); %fw frame_name=num2str(Image_Start_Number_Offset)
	frame{i} = imread(strcat(Images_Directory, Image_Prefix, frame_name, '.jpg')); %fw frame_name
	image_buffer(:,:,:,i) = uint8(frame{i});
	image_buffer = uint8(image_buffer);
end

Object_Lookup_Table = [];
Representative_Lookup_Table = [];
Object_Lookup_Table_Temp = [];
Previous_Frame_Color_Index = [];
Previous_Frame_Color_Index_Occupy = [];
Previous_Frame_Color_Index_Temp = [];

tic; % 04/17/2017
% Load RCNN Log
for j = 1:frame_number	% Loop thru frame
	disp(strcat('Processing Frame ',num2str(j)));
    frame_name=num2str(j-1,'%04d');
	d = dir(strcat(RCNN_Info_Directory, 'frame_', frame_name ,'_person_obj' , '*.mat'));
    %fw d = dir(strcat(RCNN_Info_Directory, num2str(Image_Start_Number_Offset+j), '\*.mat'));
	[Object_number dummy] = size(d);
	if j == 1
		for k = 1:Object_number	% Loop thru object
			current_RCNN_mat_filename = d(k).name;
			load(strcat(RCNN_Info_Directory, current_RCNN_mat_filename));
            %fw load(strcat(RCNN_Info_Directory, num2str(Image_Start_Number_Offset+j), '\',current_RCNN_mat_filename));
			vertical_top = max(ceil(bbox(2)),1);
			vertical_bottom = min(floor(bbox(4)),height-1);
			horizontal_left = max(ceil(bbox(1)),1);
			horizontal_right = min(floor(bbox(3)),width-1);
			Object_Lookup_Table(k).bbox = bbox; 		Representative_Lookup_Table(k).bbox = bbox; 
			Object_Lookup_Table(k).score = score;       Representative_Lookup_Table(k).score = score;
			Object_Lookup_Table(k).feature = feature;   Representative_Lookup_Table(k).feature = feature;
			Object_Lookup_Table(k).image = obj_image;   Representative_Lookup_Table(k).image = obj_image;
			Object_Lookup_Table(k).frameid = j;         Representative_Lookup_Table(k).frameid = j;
			Object_Lookup_Table(k).objectid = k;        Representative_Lookup_Table(k).objectid = k;
			Object_Lookup_Table(k).color = k;           Representative_Lookup_Table(k).color = k;
														Representative_Lookup_Table(k).occurence = 1;
														Representative_Lookup_Table(k).mv = [0 0];
														Representative_Lookup_Table(k).locationhistory = [vertical_bottom (horizontal_left+horizontal_right)/2];
														Representative_Lookup_Table(k).occurencehistory = [j];
														Representative_Lookup_Table(k).bboxhistory = [bbox];%2017
														Representative_Lookup_Table(k).scorehistory = [score];%2017
														Representative_Lookup_Table(k).featurehistory = [feature];%2017
														Representative_Lookup_Table(k).objectidhistory = [k];
														%Representative_Lookup_Table(k).imagehistory = [obj_image];%2017
			Previous_Frame_Color_Index = [Previous_Frame_Color_Index; k];
			Previous_Frame_Color_Index_Occupy = [Previous_Frame_Color_Index_Occupy; 0];
			clear bbox; clear obj_image; clear score; clear feature;
		end
	else % j ~= 1
		Previous_Frame_Color_Index_Temp = [];
		Previous_Frame_Color_Index_Occupy = zeros(length(Representative_Lookup_Table),1);
		for k = 1:Object_number	% Loop thru object in the current frame
			distance_max = 1e10;
			current_RCNN_mat_filename = d(k).name;
			load(strcat(RCNN_Info_Directory, current_RCNN_mat_filename));
            %fw load(strcat(RCNN_Info_Directory, num2str(Image_Start_Number_Offset+j), '\',current_RCNN_mat_filename));
			feature_current = feature;            			
			Object_Lookup_Table_Temp(k).bbox = bbox;
			Object_Lookup_Table_Temp(k).score = score;
			Object_Lookup_Table_Temp(k).feature = feature;
			Object_Lookup_Table_Temp(k).image = obj_image;
			Object_Lookup_Table_Temp(k).frameid = j;
			Object_Lookup_Table_Temp(k).objectid = k;
			Object_Lookup_Table_Temp(k).mv = [0 0];
			distance_max = 1e10;
            NotFound = 0;
            
			optimal_p = -1;  
			for q = 1:length(Representative_Lookup_Table)	% Loop thru object in the representative frame
				p = length(Representative_Lookup_Table) + 1 - q;
                %fwfw adjust order
                %if View==5
                %    p=q;
                %end
				% feature_previous = Representative_Lookup_Table(p).feature; % 20170123 - Use averaged RCNN
                if Representative_Lookup_Table(p).occurence~=1
                    feature_previous = mean(Representative_Lookup_Table(p).featurehistory); % 20170123 - Use averaged RCNN
                else
                    feature_previous = Representative_Lookup_Table(p).featurehistory; % 20170123 - Use averaged RCNN
                end
				
				distance = sum(sum((feature_current - feature_previous).^2))/4096;	% MSE

				top_previous = max(ceil(Representative_Lookup_Table(p).bbox(2)),1);
				bottom_previous = min(floor(Representative_Lookup_Table(p).bbox(4)), height-1);
				left_previous = max(ceil(Representative_Lookup_Table(p).bbox(1)),1);
				right_previous = min(floor(Representative_Lookup_Table(p).bbox(3)),width-1);

				top_current = max(ceil(bbox(2)),1);
				bottom_current = min(floor(bbox(4)), height-1);
				left_current = max(ceil(bbox(1)),1);
				right_current = min(floor(bbox(3)),width-1);
				
				mask_Previous = zeros(height, width);
				mask_Current = zeros(height, width);
				mask_Previous_temp = zeros(height, width);

                offsetV = round(Representative_Lookup_Table(p).mv(1) * ( j - Representative_Lookup_Table(p).frameid ));
                offsetH = round(Representative_Lookup_Table(p).mv(2) * ( j - Representative_Lookup_Table(p).frameid ));
                if (bottom_previous+offsetV < height & right_previous+offsetH < width & top_previous+offsetV > 0 & left_previous+offsetH > 0)
                    mask_Previous(top_previous+offsetV:bottom_previous+offsetV, left_previous+offsetH:right_previous+offsetH) = 1;
                else
                    mask_Previous(top_previous:bottom_previous, left_previous:right_previous) = 1; 
                end
				mask_Previous_temp(top_previous:bottom_previous, left_previous:right_previous) = 1; %%% 0824
				mask_Current(top_current:bottom_current, left_current:right_current) = 1;
				mask_intersection = zeros(height, width); mask_intersection = mask_Previous & mask_Current;
				mask_union = zeros(height, width); mask_union = mask_Previous | mask_Current;
				IOU = sum(sum(mask_intersection)) / sum(sum(mask_union));			
				mask_intersection_temp = zeros(height, width); mask_intersection_temp = mask_Previous_temp & mask_Current;
				mask_union_temp = zeros(height, width); mask_union_temp = mask_Previous_temp | mask_Current;
				IOU_temp = sum(sum(mask_intersection_temp)) / sum(sum(mask_union_temp));
				IOU = max(IOU, IOU_temp);
				if (IOU > IOU_Threshold) & (distance < distance_max) & (Object_Lookup_Table_Temp(k).frameid - Representative_Lookup_Table(p).frameid <= Temporal_Distance_Threshold)
                    if Previous_Frame_Color_Index_Occupy(p) == 0 % color not occupied
						distance_max = distance;
						optimal_p = p;
                        Object_Lookup_Table_Temp(k).color = Representative_Lookup_Table(p).color;   % Copy color from object in previous frame
						Object_Lookup_Table_Temp(k).occurence = Representative_Lookup_Table(p).occurence + 1;
						if length(find( frame{j}(1:2:end,1:2:end,2) ~= frame{j-1}(1:2:end,1:2:end,2) ))~=0
							Object_Lookup_Table_Temp(k).mv = -[(bottom_current-top_current)/2-(bottom_previous-top_previous)/2 (right_current-left_current)/2-(right_previous-left_previous)/2];
						else
							Object_Lookup_Table_Temp(k).mv = Representative_Lookup_Table(p).mv;
                        end
                        Object_Lookup_Table_Temp(k).locationhistory = [Representative_Lookup_Table(p).locationhistory; bottom_current (left_current+right_current)/2]; 
						Object_Lookup_Table_Temp(k).occurencehistory = [Representative_Lookup_Table(p).occurencehistory; j];
						Object_Lookup_Table_Temp(k).bboxhistory = [Representative_Lookup_Table(p).bboxhistory; bbox];%2017
						Object_Lookup_Table_Temp(k).scorehistory = [Representative_Lookup_Table(p).scorehistory; score];%2017
						Object_Lookup_Table_Temp(k).featurehistory = [Representative_Lookup_Table(p).featurehistory; feature];%2017
						Object_Lookup_Table_Temp(k).objectidhistory = [Representative_Lookup_Table(p).objectidhistory; k];%2017
						%Object_Lookup_Table_Temp(k).imagehistory = [Representative_Lookup_Table(p).imagehistory; obj_image];%2017
                    else % color occupied
                        NotFound = NotFound + 1;
                    end
                else
                    NotFound = NotFound + 1;
                end
                if NotFound == length(Representative_Lookup_Table) % Not Match for all objects in previous frames, give new color
					Color_Complement = fliplr(setdiff([1:length(bb_color)],Previous_Frame_Color_Index));
					Object_Lookup_Table_Temp(k).color = Color_Complement(1);
					Object_Lookup_Table_Temp(k).occurence = 1;
					Object_Lookup_Table_Temp(k).mv = [0 0];
					Previous_Frame_Color_Index = [Previous_Frame_Color_Index; Color_Complement(1)];
                    Object_Lookup_Table_Temp(k).locationhistory = [bottom_current (left_current+right_current)/2]; % 2016/12/19
					Object_Lookup_Table_Temp(k).occurencehistory = [j];
					Object_Lookup_Table_Temp(k).bboxhistory = [bbox];%2017
					Object_Lookup_Table_Temp(k).scorehistory = [score];%2017
					Object_Lookup_Table_Temp(k).featurehistory = [feature];%2017
					Object_Lookup_Table_Temp(k).objectidhistory = [k];%2017
					%Object_Lookup_Table_Temp(k).imagehistory = [obj_image];%2017
				else	% Found match in virtual frame buffer
                end  
            end % p - representative frame object
			if optimal_p ~= -1
				Previous_Frame_Color_Index_Occupy(optimal_p) = 1;   % This color is occupied
			end
            Previous_Frame_Color_Index_Temp = [Previous_Frame_Color_Index_Temp; Object_Lookup_Table_Temp(k).color]; 
			% Till this point, found optimal color index and back up
		end % k - current frame object
		
		Representative_Lookup_Table_Lookup = [Representative_Lookup_Table(:).color];
		Representative_Lookup_Table_Temp = [];
		candidate_number = length(Representative_Lookup_Table);
        
		for m = 1:Object_number	% current frame object loop
			for n = 1:candidate_number	% virtual frame object loop
				if Object_Lookup_Table_Temp(m).color == Representative_Lookup_Table(n).color	% Pointing to the same object, update
					Representative_Lookup_Table(n).bbox = Object_Lookup_Table_Temp(m).bbox;	% updated to current frame bb information
					Representative_Lookup_Table(n).score = Object_Lookup_Table_Temp(m).score;
					if Object_Lookup_Table_Temp(m).occurence ~= 1
						Representative_Lookup_Table(n).feature = ( (Representative_Lookup_Table(n).feature)*(Object_Lookup_Table_Temp(m).occurence-1)+Object_Lookup_Table_Temp(m).feature )/(Object_Lookup_Table_Temp(m).occurence);
					else % Object_Lookup_Table_Temp(m).occurence == 1
						Representative_Lookup_Table(n).feature = Object_Lookup_Table_Temp(m).feature;
					end
					Representative_Lookup_Table(n).image = Object_Lookup_Table_Temp(m).image;
					Representative_Lookup_Table(n).frameid = Object_Lookup_Table_Temp(m).frameid;	% updated to current frame id
					Representative_Lookup_Table(n).objectid = Object_Lookup_Table_Temp(m).objectid;
					Representative_Lookup_Table(n).occurence = Object_Lookup_Table_Temp(m).occurence;
					Representative_Lookup_Table(n).locationhistory = Object_Lookup_Table_Temp(m).locationhistory;
					Representative_Lookup_Table(n).occurencehistory = Object_Lookup_Table_Temp(m).occurencehistory;
					Representative_Lookup_Table(n).mv = Object_Lookup_Table_Temp(m).mv;
					Representative_Lookup_Table(n).bboxhistory = Object_Lookup_Table_Temp(m).bboxhistory;%2017
					Representative_Lookup_Table(n).scorehistory = Object_Lookup_Table_Temp(m).scorehistory;%2017
					Representative_Lookup_Table(n).featurehistory = Object_Lookup_Table_Temp(m).featurehistory;%2017
					Representative_Lookup_Table(n).objectidhistory = Object_Lookup_Table_Temp(m).objectidhistory;%2017
					%Representative_Lookup_Table(n).imagehistory = Object_Lookup_Table_Temp(m).imagehistory;%2017
				end
            end
			if length(find(Object_Lookup_Table_Temp(m).color==Representative_Lookup_Table_Lookup))==0 % New Color			
				Representative_Lookup_Table(length(Representative_Lookup_Table)+1).bbox = Object_Lookup_Table_Temp(m).bbox; %1
				Representative_Lookup_Table(length(Representative_Lookup_Table)).score = Object_Lookup_Table_Temp(m).score; %2
				Representative_Lookup_Table(length(Representative_Lookup_Table)).feature = Object_Lookup_Table_Temp(m).feature; %3
				Representative_Lookup_Table(length(Representative_Lookup_Table)).image = Object_Lookup_Table_Temp(m).image; %4
				Representative_Lookup_Table(length(Representative_Lookup_Table)).frameid = Object_Lookup_Table_Temp(m).frameid; %5
				Representative_Lookup_Table(length(Representative_Lookup_Table)).objectid = Object_Lookup_Table_Temp(m).objectid; %6
				Representative_Lookup_Table(length(Representative_Lookup_Table)).color = Object_Lookup_Table_Temp(m).color; %7
				Representative_Lookup_Table(length(Representative_Lookup_Table)).occurence = Object_Lookup_Table_Temp(m).occurence; %8
				Representative_Lookup_Table(length(Representative_Lookup_Table)).mv = Object_Lookup_Table_Temp(m).mv; %9
				Representative_Lookup_Table(length(Representative_Lookup_Table)).locationhistory = Object_Lookup_Table_Temp(m).locationhistory; %10
				Representative_Lookup_Table(length(Representative_Lookup_Table)).occurencehistory = Object_Lookup_Table_Temp(m).occurencehistory; %10
				Representative_Lookup_Table(length(Representative_Lookup_Table)).bboxhistory = Object_Lookup_Table_Temp(m).bboxhistory; %2017
				Representative_Lookup_Table(length(Representative_Lookup_Table)).scorehistory = Object_Lookup_Table_Temp(m).scorehistory; %2017
				Representative_Lookup_Table(length(Representative_Lookup_Table)).featurehistory = Object_Lookup_Table_Temp(m).featurehistory; %2017
				Representative_Lookup_Table(length(Representative_Lookup_Table)).objectidhistory = Object_Lookup_Table_Temp(m).objectidhistory; %2017
			end
		end
		Previous_Frame_Color_Index = [];
		for pp = 1:length(Representative_Lookup_Table)
			Previous_Frame_Color_Index = [Previous_Frame_Color_Index; Representative_Lookup_Table(pp).color];
        end
	end
	Representative_Lookup_Table_Examinatoin{j} = Representative_Lookup_Table;
	Previous_Frame_Color_Index_Examination{j} = Previous_Frame_Color_Index;
end % j - frame

% Intra-View Graph Matching - START
% Temporal Overlapping Verification

if IntraViewGM_Enabled

candidate_list = [];
for k = 1:length(Representative_Lookup_Table)
    for p = k+1:length(Representative_Lookup_Table)
        cur_occurencehistory = Representative_Lookup_Table(k).occurencehistory;
        ref_occurencehistory = Representative_Lookup_Table(p).occurencehistory;
        if (max(cur_occurencehistory) < min(ref_occurencehistory) | min(cur_occurencehistory) > max(ref_occurencehistory)) && length(cur_occurencehistory)>1 && length(ref_occurencehistory)>1
             candidate_list = [candidate_list; k p;];
        end
    end
end
candidate_list

parFgmA = st('nItMa', 100, 'nAlp', 101, 'deb', 'n', 'ip', 'n', 'lamQ', .5);
egDen = 0.5;
parGph = st('link', 'full', 'val', egDen);
[row col] = size(candidate_list);
for r = 1:row
    bypassGM = 0;
    clear end_frame_object_mv;
    end_frame = Representative_Lookup_Table(candidate_list(r,1)).occurencehistory(end);
    start_frame = Representative_Lookup_Table(candidate_list(r,2)).occurencehistory(1);
    zooming_factor = 5;
	
    % Results post-filtering by spatial offset: delta_L < mv * delta_t
    end_frame_object_centroid = [(Representative_Lookup_Table(candidate_list(r,1)).bboxhistory(end,2)+Representative_Lookup_Table(candidate_list(r,1)).bboxhistory(end,4))/2 (Representative_Lookup_Table(candidate_list(r,1)).bboxhistory(end,1)+Representative_Lookup_Table(candidate_list(r,1)).bboxhistory(end,3))/2];
    start_frame_object_centroid = [(Representative_Lookup_Table(candidate_list(r,2)).bboxhistory(1,2)+Representative_Lookup_Table(candidate_list(r,2)).bboxhistory(1,4))/2 (Representative_Lookup_Table(candidate_list(r,2)).bboxhistory(1,1)+Representative_Lookup_Table(candidate_list(r,2)).bboxhistory(1,3))/2];
    end_frame_object_mv = Representative_Lookup_Table(candidate_list(r,1)).mv;
    if sqrt( sum( (end_frame_object_centroid-start_frame_object_centroid).^2 ) ) > sqrt( sum(end_frame_object_mv.^2)) * (start_frame - end_frame) * zooming_factor
        bypassGM = 1; % assume these two objects unmatched. Skip GM. Do not merge tracklets
        disp('Distance Info Mismatch! Bypass Intra-View GM!\n');
    end
    
    if start_frame - end_frame > Temporal_Distance_Threshold
        bypassGM = 1;
        disp('Two frames are too far away! Bypass Intra-View GM!\n');
    end
    
    if ~bypassGM
        disp('Triggered Intra-View GM!\n');
		% Re-trace ending Frame A
        ObjectA_index = Representative_Lookup_Table(candidate_list(r,1)).objectidhistory(end);
        frame_name=num2str(end_frame-1,'%04d');
	    d = dir(strcat(RCNN_Info_Directory, 'frame_', frame_name ,'_person_obj' , '*.mat'));
        %fw d = dir(strcat(RCNN_Info_Directory, num2str(4000+end_frame-1), '\*.mat'));
        [Object_number1 dummy] = size(d);
        Pt1 = [];
        for k = 1:Object_number1
            current_RCNN_mat_filename = d(k).name;
            load(strcat(RCNN_Info_Directory, current_RCNN_mat_filename));
            %fw load(strcat(RCNN_Info_Directory, num2str(4000+end_frame-1), '\',current_RCNN_mat_filename));
			vertical_top = max(ceil(bbox(2)),1);
			vertical_bottom = min(floor(bbox(4)),height-1);
			horizontal_left = max(ceil(bbox(1)),1);
			horizontal_right = min(floor(bbox(3)),width-1);
			rcnn1{k} = feature;
			Pt1 = [Pt1; vertical_bottom (horizontal_left+horizontal_right)/2];
		end
		clear d; clear bbox; clear obj_image; clear score; clear feature; clear k; clear Object_number; clear Object_number;
		% Re-trace starting Frame B
		ObjectB_index = Representative_Lookup_Table(candidate_list(r,2)).objectidhistory(1);
		frame_name=num2str(start_frame-1,'%04d');
	    d = dir(strcat(RCNN_Info_Directory, 'frame_', frame_name ,'_person_obj' , '*.mat'));
        %fw d = dir(strcat(RCNN_Info_Directory, num2str(4000+start_frame-1), '\*.mat'));
		[Object_number2 dummy] = size(d);   
		Pt2 = [];
		for k = 1:Object_number2
			current_RCNN_mat_filename = d(k).name;
			load(strcat(RCNN_Info_Directory, current_RCNN_mat_filename));
            %fw load(strcat(RCNN_Info_Directory, num2str(4000+start_frame-1), '\',current_RCNN_mat_filename));
			vertical_top = max(ceil(bbox(2)),1);
			vertical_bottom = min(floor(bbox(4)),height-1);
			horizontal_left = max(ceil(bbox(1)),1);
			horizontal_right = min(floor(bbox(3)),width-1);
			rcnn2{k} = feature;
			Pt2 = [Pt2; vertical_bottom (horizontal_left+horizontal_right)/2];
		end
		clear d; clear bbox; clear obj_image; clear score; clear feature; clear k; clear Object_number; clear Object_number;
		
		% KP Construction
		Pt1_t = Pt1';
		Pt2_t = Pt2';
		gphs{1} = newGphA(Pt1_t, parGph);
		gphs{2} = newGphA(Pt2_t, parGph);
        clear KP;
		for ii = 1:Object_number1
			for jj = 1:Object_number2
				KP(ii,jj) = exp(-sqrt( sum(( rcnn1{ii}-rcnn2{jj} ).^2) ));
			end
		end
		KP = double(KP);
		
		% KQ Construction
		% dst1 = []; ang1 = [];
		dst1_x = []; dst1_y = [];
		for ii = 1:length(gphs{1}.Eg)
			temp_x1 = Pt1(gphs{1}.Eg(1,ii),1);
			temp_y1 = Pt1(gphs{1}.Eg(1,ii),2);
			temp_x2 = Pt1(gphs{1}.Eg(2,ii),1);
			temp_y2 = Pt1(gphs{1}.Eg(2,ii),2);
			% Amplitude
			% dst1(ii) = sqrt( (temp_x1 - temp_x2).^2 + (temp_y1 - temp_y2).^2 );
			% Angle 
			% ang1(ii) = atan( (temp_y1 - temp_y2)/(temp_x1 - temp_x2) ) + pi/2; % convert between [0 pi]
			dst1_x(ii) = temp_x1 - temp_x2;
			dst1_y(ii) = temp_y1 - temp_y2;
		end
		% dst2 = []; ang2 = [];
		dst2_x = []; dst2_y = [];
		clear temp_x1; clear temp_x2; clear temp_y1; clear temp_y2; 
		for ii = 1:length(gphs{2}.Eg)
			temp_x1 = Pt2(gphs{2}.Eg(1,ii),1);
			temp_y1 = Pt2(gphs{2}.Eg(1,ii),2);
			temp_x2 = Pt2(gphs{2}.Eg(2,ii),1);
			temp_y2 = Pt2(gphs{2}.Eg(2,ii),2);
			% Amplitude
			% dst2(ii) = sqrt( (temp_x1 - temp_x2).^2 + (temp_y1 - temp_y2).^2 );
			% Angle 
			% ang2(ii) = atan( (temp_y1 - temp_y2)/(temp_x1 - temp_x2) ) + pi/2; % convert between [0 pi]
			dst2_x(ii) = temp_x1 - temp_x2;
			dst2_y(ii) = temp_y1 - temp_y2;			
        end
        clear KQ;
		for ii = 1:length(gphs{1}.Eg)
			for jj = 1:length(gphs{2}.Eg)
				% KQ(ii,jj) = exp( -abs( dst1_x(ii) - dst2_x(jj) ) ) * exp( -abs(ang1(ii)-ang2(jj)) );
				KQ(ii,jj) = exp( -sqrt( (dst1_x(ii) - dst2_x(jj))^2 + (dst1_y(ii) - dst2_y(jj))^2 ) );
			end
		end
		KQ = double(KQ);
		
		% Single-View Graph Matching
		Ct = ones(size(KP));
		asgFgmD = fgmD_Cisco(KP, KQ, Ct, gphs, parFgmA);
		
		% Check Matching results and determine whether to link object tracklet
		for jj = 1:min(Object_number1,Object_number2)
            if sum(asgFgmD.X(jj,:))~=0
                matching_object_idx(jj) = find( asgFgmD.X(jj,:)==1);
            else
                continue;
            end
		end
		matched_entry_in_FrameB = matching_object_idx(ObjectA_index);
		if matched_entry_in_FrameB ~= ObjectB_index
			% Invalid match. Do not merge tracklet. Do not update VOB
			;
        else
			Representative_Lookup_Table_backup = Representative_Lookup_Table;
			Representative_Lookup_Table(candidate_list(r,2)).color = Representative_Lookup_Table(candidate_list(r,1)).color;
            disp('Valid Single-View GM! Merge Tracklet! Update VOB');
		end
		
		% Check GM Results
		if IsDebugging
			frame_name=num2str(end_frame-1,'%04d'); 
	        frame1 = imread(strcat(Images_Directory, Image_Prefix, frame_name, '.jpg')); 
            frame_name=num2str(start_frame-1,'%04d'); 
	        frame2 = imread(strcat(Images_Directory, Image_Prefix, frame_name, '.jpg')); 
            %fw frame1 = imread(strcat(Images_Directory, Image_Prefix, num2str(4000+end_frame-1), '.jpg'));
			%fw frame2 = imread(strcat(Images_Directory, Image_Prefix, num2str(4000+start_frame-1), '.jpg'));
			R = 3;
			for j = 1:min(Object_number1,Object_number2)
				matching_object_idx(j) = find( asgFgmD.X(j,:)==1);
				frame1(Pt1_t(1,j)-R:Pt1_t(1,j)+R,Pt1_t(2,j)-R:Pt1_t(2,j)+R,1) = bb_color{j+1}(1);
				frame1(Pt1_t(1,j)-R:Pt1_t(1,j)+R,Pt1_t(2,j)-R:Pt1_t(2,j)+R,2) = bb_color{j+1}(2);
				frame1(Pt1_t(1,j)-R:Pt1_t(1,j)+R,Pt1_t(2,j)-R:Pt1_t(2,j)+R,3) = bb_color{j+1}(3);
				frame2(Pt2_t(1,matching_object_idx(j))-R:Pt2_t(1,matching_object_idx(j))+R,Pt2_t(2,matching_object_idx(j))-R:Pt2_t(2,matching_object_idx(j))+R,1) = bb_color{j+1}(1);
				frame2(Pt2_t(1,matching_object_idx(j))-R:Pt2_t(1,matching_object_idx(j))+R,Pt2_t(2,matching_object_idx(j))-R:Pt2_t(2,matching_object_idx(j))+R,2) = bb_color{j+1}(2);
				frame2(Pt2_t(1,matching_object_idx(j))-R:Pt2_t(1,matching_object_idx(j))+R,Pt2_t(2,matching_object_idx(j))-R:Pt2_t(2,matching_object_idx(j))+R,3) = bb_color{j+1}(3);	
			end
			figure; imshow(frame1,[]);figure;imshow(frame2,[]);
		end
		
	end % ~bypassGM
end

end
% Intra-View Graph Matching - END

% Output Results
for k = 1:length(Representative_Lookup_Table)
	t_frame_index = round( Representative_Lookup_Table(k).occurencehistory );
	t_bbox = round( Representative_Lookup_Table(k).bboxhistory );
	t_color = Representative_Lookup_Table(k).color;
	for r = 1:length(t_frame_index)   
        t = t_frame_index(r);
        itop = max(t_bbox(r,2),1);
        ibottom = min(t_bbox(r,4),height);
        ileft = max(t_bbox(r,1),1);
        iright = min(t_bbox(r,3),width);
        image_buffer([itop ibottom],ileft:iright,1,t) = bb_color{t_color}(1); 
        image_buffer(itop:ibottom,[ileft iright],1,t) = bb_color{t_color}(1); 
        image_buffer([itop ibottom],ileft:iright,2,t) = bb_color{t_color}(2); 
        image_buffer(itop:ibottom,[ileft iright],2,t) = bb_color{t_color}(2); 
        image_buffer([itop ibottom],ileft:iright,3,t) = bb_color{t_color}(3); 
        image_buffer(itop:ibottom,[ileft iright],3,t) = bb_color{t_color}(3);       
% 		image_buffer([t_bbox(r,2) t_bbox(r,4)],t_bbox(r,1):t_bbox(r,3),1,t) = bb_color{t_color}(1); 
% 		image_buffer(t_bbox(r,2):t_bbox(r,4),[t_bbox(r,1) t_bbox(r,3)],1,t) = bb_color{t_color}(1);
% 		image_buffer([t_bbox(r,2) t_bbox(r,4)],t_bbox(r,1):t_bbox(r,3),2,t) = bb_color{t_color}(2); 
% 		image_buffer(t_bbox(r,2):t_bbox(r,4),[t_bbox(r,1) t_bbox(r,3)],2,t) = bb_color{t_color}(2);
% 		image_buffer([t_bbox(r,2) t_bbox(r,4)],t_bbox(r,1):t_bbox(r,3),3,t) = bb_color{t_color}(3); 
% 		image_buffer(t_bbox(r,2):t_bbox(r,4),[t_bbox(r,1) t_bbox(r,3)],3,t) = bb_color{t_color}(3);
	end
end

if ShowProcessingImage
	for j = 1:frame_number
		figure;imshow(image_buffer(:,:,:,j),[]); title(num2str(Image_Start_Number_Offset+j));
	end
end

if Write2MP4
	myObj = VideoWriter(strcat(output_video_file_name,'.mp4'),'MPEG-4');
	myObj.FrameRate = 10;
	writerObj.FrameRate = 1;
	open(myObj);
	for i=1:frame_number
		writeVideo(myObj,image_buffer(:,:,:,i));
	end 
	close(myObj);
end

if Write2JPG
	for i=1:frame_number
		imwrite(image_buffer(:,:,:,i),strcat(num2str(Image_Start_Number_Offset+i),'.jpg'));
	end 
end

if PostProcessing
    %color_label = []; dup_index = [];
	%for i = 1:length(Representative_Lookup_Table)
	%	color_label = [color_label; Representative_Lookup_Table(i).color];
	%end
	%for i = 1:length(Representative_Lookup_Table)
	%	if length( find(color_label==Representative_Lookup_Table(i).color) ) > 1 % duplicate entries
	%		 temp = find(color_label==Representative_Lookup_Table(i).color);
	%		 dup_index = [dup_index; temp()];
	%	end
	%end
	%dup_index = unique(dup_index);
	%for j = 2:length(dup_index)
	%	Representative_Lookup_Table(dup_index(1)).bboxhistory = [Representative_Lookup_Table(dup_index(1)).bboxhistory; Representative_Lookup_Table(dup_index(j)).bboxhistory];
	%	Representative_Lookup_Table(dup_index(1)).occurencehistory = [Representative_Lookup_Table(dup_index(1)).occurencehistory; Representative_Lookup_Table(dup_index(j)).occurencehistory];
	%	Representative_Lookup_Table(dup_index(1)).locationhistory = [Representative_Lookup_Table(dup_index(1)).locationhistory; Representative_Lookup_Table(dup_index(j)).locationhistory];
	%	Representative_Lookup_Table(dup_index(1)).featurehistory = [Representative_Lookup_Table(dup_index(1)).featurehistory; Representative_Lookup_Table(dup_index(j)).featurehistory];
	%	Representative_Lookup_Table(dup_index(1)).occurence = Representative_Lookup_Table(dup_index(1)).occurence + Representative_Lookup_Table(dup_index(j)).occurence;
	%	Representative_Lookup_Table(dup_index(j)) = [];
    %end
	%fwfw Don't_comment_when_doing_del_V7 Representative_Lookup_Table = Representative_Lookup_Table_backup; 
    clear color; 
	color = [1 Representative_Lookup_Table(1).color];
	temp_index = [];
	for i = 2:length(Representative_Lookup_Table)
		if find(color(:,2)==Representative_Lookup_Table(i).color) & Representative_Lookup_Table(i).color~=0
			index = color(find(color(:,2)==Representative_Lookup_Table(i).color),1);
			Representative_Lookup_Table(index).bboxhistory = [Representative_Lookup_Table(index).bboxhistory; Representative_Lookup_Table(i).bboxhistory];
			Representative_Lookup_Table(index).occurencehistory = [Representative_Lookup_Table(index).occurencehistory; Representative_Lookup_Table(i).occurencehistory];
			Representative_Lookup_Table(index).locationhistory = [Representative_Lookup_Table(index).locationhistory; Representative_Lookup_Table(i).locationhistory];
			Representative_Lookup_Table(index).featurehistory = [Representative_Lookup_Table(index).featurehistory; Representative_Lookup_Table(i).featurehistory];
			Representative_Lookup_Table(index).occurence = Representative_Lookup_Table(index).occurence + Representative_Lookup_Table(i).occurence;
			Representative_Lookup_Table(i).color = 0;
			temp_index = [temp_index i];
		else
			color = [color; i Representative_Lookup_Table(i).color];
		end
	end
	Representative_Lookup_Table(temp_index) = [];
end
toc; % 04/17/2017
duration = toc; % 04/17/2017

if SaveTracklets | 1
    for iter = 1:length(Representative_Lookup_Table)
        location_time_info{iter} = [Representative_Lookup_Table(iter).occurencehistory Representative_Lookup_Table(iter).locationhistory Representative_Lookup_Table(iter).featurehistory];
    end
end