% ===============================================================================================
% Project: Cross-Camera Human Tracking (Cisco)
% Video Lab @ NYU, Tandon School of Engineering
%
% This Program will 
% Input:
% Output: 
%
% Revision History
% 12/12/2016	By Fanyi Duanmu	- Initial Version
% 01/31/2017	By Fanyi Duanmu - Rewrite implementation from scratch
% 02/04/2017    By Fanyi Duanmu - Incorporate View 7
% 04/16/2017    By Fanyi Duanmu - Add Profiler and Timer
% ===============================================================================================
clear;clc; close all;

% Global Macro
IsDebugging = 0;
Write2JPG = 0;
Write2MP4 = 0;
Forward_Unification = 1;
Backward_Unification = 0;
frame_number = 100;
EnableKQ = 0;

% Load Pre-saved VOB
load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_V1\Representative_Lookup_Table_V1_f200_Merge.mat'); 
%fw load('C:\1Cisco\ICIP_JPG_V1\Representative_Lookup_Table_V1_f200_Merge.mat'); 
VOB_1 = Representative_Lookup_Table; clear Representative_Lookup_Table; VOB_1_orig = VOB_1;
load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_V7\Representative_Lookup_Table_V7_f200_Merge.mat'); 
%fw load('C:\1Cisco\ICIP_JPG_V7\Representative_Lookup_Table_V7_f200_Merge.mat'); 
VOB_2 = Representative_Lookup_Table; clear Representative_Lookup_Table; VOB_2_orig = VOB_2;

tic;
% GM Trigger Framestamp Calculation
start_frame_index = [];
for temp = 1:length(VOB_2)
	start_frame_index = [start_frame_index; VOB_2(temp).occurencehistory(1)];
end
GM_frame_index = sort(unique(start_frame_index),'ascend');	% timestamp that new human object enters the scene, trigger GM
GM_frame_index = [GM_frame_index; frame_number];

% Load Pre-saved location info
% View 1
frame_number = 100;
width1 = 768;
height1 = 576;
load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_V1\location_time_info_V1_f100_Merge.mat');
%fw load('C:\1Cisco\ICIP_JPG_V1\location_time_info_V1_f100_Merge.mat');
location_time_info_view1 = location_time_info; clear location_time_info;
figure;
for i = 1:length(location_time_info_view1)
    location_time_info_view1_processed = zeros(frame_number,3); 
    location_time_info_view1_processed(:,1) = 1:frame_number;
    location_time_info_view1_temp = location_time_info_view1{i};
    index = location_time_info_view1_temp(:,1);
    location_time_info_view1_processed(index,:) = location_time_info_view1_temp(:,1:3);
    location_time_info_view1_processed_output{i} = location_time_info_view1_processed;
    disp_temp_buffer = zeros(height1, width1);
    for j = 1:length(location_time_info_view1_processed_output{i})
        yy = round( location_time_info_view1_processed(j,2) );
        xx = round( location_time_info_view1_processed(j,3) );
        if location_time_info_view1_processed(j,2)~=0 & location_time_info_view1_processed(j,3)~=0
            disp_temp_buffer(yy-5:yy+5,xx-5:xx+5) = 255;
        end
    end
if IsDebugging
    subplot(1,length(location_time_info_view1),i);imshow(disp_temp_buffer,[]);
end % IsDebugging
end
% View 7 (Homography Transformed)
width2 = 720;
height2 = 576;
T_7_1 = load('T_7_1.mat');
T_7_1 = cell2mat(struct2cell(T_7_1));
load('D:\Software\MATLAB\image_processing_project_fgm\1cisco\ICIP_JPG_V7\location_time_info_V7_f100_Merge.mat');
%fw load('C:\1Cisco\ICIP_JPG_V7\location_time_info_V7_f100_Merge.mat');
location_time_info_view7 = location_time_info; clear location_time_info;
figure;
for i = 1:length(location_time_info_view7)
    location_time_info_view7_processed = zeros(frame_number,3); 
    location_time_info_view7_processed(:,1) = 1:frame_number;
    location_time_info_view7_temp = location_time_info_view7{i};    
    index = location_time_info_view7_temp(:,1);
    location_time_info_view7_processed(index,:) = location_time_info_view7_temp(:,1:3); 
    location_xy = location_time_info_view7_processed(:,2:3);
    Pt2_backup_seq = location_xy';
    Pt2_swap_seq(1,:) = Pt2_backup_seq(2,:); 
    Pt2_swap_seq(2,:) = Pt2_backup_seq(1,:);
    location_xy_T = round( homography_transform(Pt2_swap_seq,T_7_1) );
    Pt2_seq(1,:) = location_xy_T(2,:);
    Pt2_seq(2,:) = location_xy_T(1,:);
	Pt2_seq(Pt2_seq>max(max(width1, width2),max(height1, height2)))=-1;	% After homography projection, out of boundary
    location_time_info_view7_processed_output{i} = [location_time_info_view7_processed(:,1) Pt2_seq'];
    disp_temp_buffer1 = zeros(height2, width2);   
    disp_temp_buffer2 = zeros(height2, width2);
    for j = 1:length(location_time_info_view7_processed_output{i})
        yy = round( location_time_info_view7_processed_output{i}(j,2) );
        xx = round( location_time_info_view7_processed_output{i}(j,3) );
        yy2 = round( location_time_info_view7_processed(j,2) );
        xx2 = round( location_time_info_view7_processed(j,3) );
        if location_time_info_view7_processed_output{i}(j,2)>0 & location_time_info_view7_processed_output{i}(j,3)>0
            disp_temp_buffer2(yy-5:yy+5,xx-5:xx+5) = 255;
            disp_temp_buffer1(yy2-5:yy2+5,xx2-5:xx2+5) = 255;
        end
    end
if IsDebugging | 1
    subplot(2,length(location_time_info_view7),i); imshow(disp_temp_buffer1); title('Original');
    subplot(2,length(location_time_info_view7),i+length(location_time_info_view7)); imshow(disp_temp_buffer2);title('Transformed');
end % IsDebugging
end

color_label_merge_lookup = [];
for chunk_index = 1:length(GM_frame_index)-1
	% GM over this chunk
	% KP Construction
	clear x1; clear y1; clear x2; clear y2; clear KP; clear KQ;
	for i = 1:length(location_time_info_view1_processed_output)
		for j = 1:length(location_time_info_view7_processed_output)
			ratio_mse_x = 0; ratio_mse_y = 0; counter = 0;
			x1{i} = location_time_info_view1_processed_output{i}(GM_frame_index(chunk_index):(GM_frame_index(chunk_index+1)-1),2);
			y1{i} = location_time_info_view1_processed_output{i}(GM_frame_index(chunk_index):(GM_frame_index(chunk_index+1)-1),3);
			x2{j} = location_time_info_view7_processed_output{j}(GM_frame_index(chunk_index):(GM_frame_index(chunk_index+1)-1),2);
			y2{j} = location_time_info_view7_processed_output{j}(GM_frame_index(chunk_index):(GM_frame_index(chunk_index+1)-1),3);			
			for k = 1:length(x1{i}) % for inside chunk
				if (x1{i}(k))>0 & (x2{j}(k))>0 & (y1{i}(k))>0 & (y2{j}(k))>0 % co-detected from two views
					counter = counter + 1;
					ratio_mse_x = ratio_mse_x + ( sum( ( x1{i}(k) - x2{j}(k)).^2 ) );
					ratio_mse_y = ratio_mse_y + ( sum( ( y1{i}(k) - y2{j}(k)).^2 ) );				
				end % (x1{i}(k))>0 & (x2{j}(k))>0 & (y1{i}(k))>0 & (y2{j}(k))>0)
			end % k
			KP(i,j) = 1/(sqrt((ratio_mse_x+ratio_mse_y))/counter + 1e-8);
			% KP(ii,jj) = exp(- (sqrt( (ratio_mse_x+ratio_mse_y) )/counter + 1e-8) );			
		end % j
	end % i
	KP(isnan(KP))=0;
	
	% Pinpoint Object Index
	V7_obj_index = []; V1_obj_index = [];
	[M N] = size(KP);
	for p = 1:N
		if sum( KP(:,p) ) ~=0
			V7_obj_index = [V7_obj_index p];
		end
	end
	for p = 1:M
		if sum( KP(p,:) ) ~=0
			V1_obj_index = [V1_obj_index p];
		end
	end
	clear p;
		
	% Graph Structure Construction
	for t = 1:length(location_time_info_view1_processed_output)
        Pt1_temporal(1:length(x1{t}),t) = round(x1{t}(:));
        Pt1_temporal(1+length(x1{t}):length(x1{t})+length(y1{t}),t) = round(y1{t}(:));	% Cancatenation
	end
	for t = 1:length(location_time_info_view7_processed_output)
        Pt2_temporal(1:length(x2{t}),t) = round(x2{t}(:));
        Pt2_temporal(1+length(x2{t}):length(x2{t})+length(y2{t}),t) = round(y2{t}(:));	% Cancatenation
	end
	Pt2_temporal(Pt2_temporal<=0)=0;
	% Comment: Pt1_temporal,Pt2_temporal horizontal is sample number, vertical is sample dimension
	
	% Graph Default Parameters
	parFgmA_temporal = st('nItMa', 100, 'nAlp', 300, 'deb', 'n', 'ip', 'n', 'lamQ', .5);
	parGph_temporal = st('link', 'full', 'val', 0.5);
	
	gphs_temporal{1} = newGphA(Pt1_temporal, parGph_temporal);
	gphs_temporal{2} = newGphA(Pt2_temporal, parGph_temporal);
	
    P1 = nchoosek(length(location_time_info_view1_processed_output),2) * 2; 	% bi-directional
	P2 = nchoosek(length(location_time_info_view7_processed_output),2) * 2; 	% bi-directional
	%fw P1 = combntns(length(location_time_info_view1_processed_output),2) * 2; 	% bi-directional
	%fw P2 = combntns(length(location_time_info_view7_processed_output),2) * 2; 	% bi-directional
	KQ = zeros(P1,P2);

if EnableKQ	
	temp1 = [];
	for i = 1:length(gphs_temporal{1}.Eg)
		dst1(i) = sqrt( sum( ( location_xy(gphs_temporal{1}.Eg(1,i),:) - location_xy(gphs_temporal{1}.Eg(2,i),:)).^2 ) );	% Euclidean-Distance for all trajectory element
		dx1(i) = location_xy(gphs_temporal{1}.Eg(1,i),1) - location_xy(gphs_temporal{1}.Eg(2,i),1);
		dy1(i) = location_xy(gphs_temporal{1}.Eg(1,i),2) - location_xy(gphs_temporal{1}.Eg(2,i),2);
		temp1 = [temp1; dst1(i)];
	end
	temp2 = [];
	for i = 1:length(gphs_temporal{2}.Eg)
		dst2(i) = sqrt( sum( ( location_xy_T(gphs_temporal{2}.Eg(1,i),:) - location_xy_T(gphs_temporal{2}.Eg(2,i),:)).^2 ) ); % Euclidean-Distance for all trajectory element
		dx2(i) = location_xy_T(gphs_temporal{1}.Eg(1,i),1) - location_xy_T(gphs_temporal{2}.Eg(2,i),1);
		dy2(i) = location_xy_T(gphs_temporal{1}.Eg(1,i),2) - location_xy_T(gphs_temporal{2}.Eg(2,i),2);
		temp2 = [temp2; dst2(i)];
	end
	% Normalization
	dst1 = dst1/sqrt(var([temp1' temp2']));
	dst2 = dst2/sqrt(var([temp1' temp2']));
	temp = [];
	for i = 1:length(gphs_temporal{1}.Eg)
		for j = 1:length(gphs_temporal{2}.Eg)
			% 1215 KQ(i,j) = exp( -abs( dst1(i) - dst2(j) ) ); %% 1215
			KQ(i,j) = exp( -abs(dx1(i)-dx2(j)) -abs(dy1(i)-dy2(j)) );
			temp = [temp; KQ(i,j)];	
		end
	end
end	
		
	KQ = double(KQ);
	Ct = ones(size(KP));	% Controls eligibility
	asgFgmD_temporal = fgmD_Cisco(KP, KQ, Ct, gphs_temporal, parFgmA_temporal);  
%fwfw modify start point	
	% For correct match, update/link VOB objects
	for iter = 1:length(V7_obj_index)
		match_index(iter) = find(asgFgmD_temporal.X(:,V7_obj_index(iter))); % matched index in V1
		match_distance(iter) = 0;
		counter = 0;
		for kk = 1:length(x2{1})
			if x2{V7_obj_index(iter)}(kk)>0 & x1{match_index(iter)}(kk)>0 & y2{V7_obj_index(iter)}(kk)>0 & y1{match_index(iter)}(kk)>0
				match_distance(iter) = match_distance(iter) + ( x2{V7_obj_index(iter)}(kk) - x1{match_index(iter)}(kk) )^2 + ( y2{V7_obj_index(iter)}(kk) - y1{match_index(iter)}(kk) )^2;
				counter = counter+1;
			end
		end
		match_distance(iter) =  sqrt(match_distance(iter))/counter;		
    end
    for iter = 1+length(V7_obj_index):2*length(V7_obj_index)
		match_index(iter) = find(asgFgmD_temporal.X(:,V7_obj_index(iter))); % matched index in V1
		match_distance(iter) = 0;
		counter = 0;
		for kk = 1:length(x2{1})
			if x2{V7_obj_index(iter)}(kk)>0 & x1{match_index(iter)}(kk)>0 & y2{V7_obj_index(iter)}(kk)>0 & y1{match_index(iter)}(kk)>0
				match_distance(iter) = match_distance(iter) + ( x2{V7_obj_index(iter)}(kk) - x1{match_index(iter)}(kk) )^2 + ( y2{V7_obj_index(iter)}(kk) - y1{match_index(iter)}(kk) )^2;
				counter = counter+1;
			end
		end
		match_distance(iter) =  sqrt(match_distance(iter))/counter;		
	end
	conf_threshold = 10;
	for iter = 1:length(V7_obj_index)*2
        occhislen=length(VOB_2(V7_obj_index(iter)).occurencehistory);
		if match_distance(iter) < min(match_distance)*conf_threshold & VOB_2(V7_obj_index(iter)).occurencehistory(occhislen)==GM_frame_index(chunk_index)
			L_V7 = VOB_2(V7_obj_index(iter)).occurence+occhislen-1;
			L_V1 = VOB_1(match_index(iter)).occurence;
			if L_V1<=L_V7
				disp('VOB1 Label Unified using VOB2 Object Label');
				% VOB_1(V1_obj_index(match_index(iter))).color = VOB_2(V7_obj_index(iter)).color+100;	% offset 100 used to distinguish
				color_label_merge_lookup = [color_label_merge_lookup; 21 V7_obj_index(iter) match_index(iter)];
			else
				disp('VOB2 Label Unified using VOB1 Object Label');
				% VOB_2(V7_obj_index(iter)).color = VOB_1(V1_obj_index(match_index(iter))).color+200;	% offset 200 used to distinguish
				color_label_merge_lookup = [color_label_merge_lookup; 12 match_index(iter) V7_obj_index(iter)];			
			end
		else
			disp(strcat('node:',num2str(iter),'-invalid match, do not update VOB!'));
		end
	end
end % end chunk index
% fw modify stop point
if IsDebugging | 1
	color_label_merge_lookup
end

% Final VOB Update
VOB_1_backup = VOB_1; VOB_2_backup = VOB_2;
for i = 1:length(VOB_1)
	VOB_1(i).color = VOB_1(i).color + 100;
end
for i = 1:length(VOB_2)
	VOB_2(i).color = VOB_2(i).color + 200;
end

% Forward Unification
if Forward_Unification
for i = 1:length(color_label_merge_lookup)
	if color_label_merge_lookup(i,1)==21
        VOB_2( color_label_merge_lookup(i,2) ).color = VOB_1( color_label_merge_lookup(i,3) ).color;
	elseif color_label_merge_lookup(i,1)==12
		VOB_2( color_label_merge_lookup(i,3) ).color = VOB_1( color_label_merge_lookup(i,2) ).color;	
	end
end
end

% Backward Unification
if Backward_Unification
for i = 1:length(color_label_merge_lookup)
	if color_label_merge_lookup(i,1)==21 % copy from 2 to 1
		VOB_1( color_label_merge_lookup(i,3) ).color = VOB_2( color_label_merge_lookup(i,2) ).color;
	elseif color_label_merge_lookup(i,1)==12 % copy from 1 to 2
		VOB_1( color_label_merge_lookup(i,2) ).color = VOB_2( color_label_merge_lookup(i,3) ).color;	
	end
end
end

color_index_pool = [];
for i = 1:length(VOB_1)
	color_index_pool = [color_index_pool VOB_1(i).color];
end
for i = 1:length(VOB_2)
	color_index_pool = [color_index_pool VOB_2(i).color];
end
color_index_pool = unique(color_index_pool);

% Create Color Table
bb_color{1} = [255 127 80];	
bb_color{2} = [255 0 0];	
bb_color{3} = [255 255 0];	
bb_color{4} = [0 0 255];	
bb_color{5} = [0 255 0];	
bb_color{6} = [252 230 201];
bb_color{7} = [128 138 135];
bb_color{8} = [0 0 0];		
bb_color{9} = [255 192 203];
bb_color{10} = [250 128 114];
bb_color{11} = [135 38 87];	
bb_color{12} = [255 0 255];	
bb_color{13} = [128 128 105];
bb_color{14} = [255 97 0];	
bb_color{15} = [128 42 42];

% Draw VOB 1
image_buffer1 = zeros(height1, width1, 3, frame_number);
Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Dataset\PET\View_001\';
%fw Images_Directory = 'C:\1Cisco\Dataset\PET\View_001\';
Image_Prefix = 'frame_';
for i = 1:frame_number
	frame_name=num2str(i-1,'%04d');
	frame{i} = imread(strcat(Images_Directory, Image_Prefix, frame_name, '.jpg')); 
    %fw frame{i} = imread(strcat(Images_Directory, Image_Prefix, num2str(4000+i-1), '.jpg'));
	image_buffer1(:,:,:,i) = uint8(frame{i});
end
image_buffer1 = uint8(image_buffer1);
radius = 2;
for k = 1:length(VOB_1)
	t_frame_index = round( VOB_1(k).occurencehistory );
	t_bbox = round( VOB_1(k).bboxhistory );
	t_color = VOB_1(k).color;
	t_color_index = find(color_index_pool==t_color);
	for r = 1:length(t_frame_index)   
        t = t_frame_index(r);
        itop = max(t_bbox(r,2),1+radius);
        ibottom = min(t_bbox(r,4),height1-radius);
        ileft = max(t_bbox(r,1),1+radius);
        iright = min(t_bbox(r,3),width1-radius);
        image_buffer1([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,1,t) = bb_color{t_color_index}(1); 
        image_buffer1(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],1,t) = bb_color{t_color_index}(1); 
        image_buffer1([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,2,t) = bb_color{t_color_index}(2); 
        image_buffer1(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],2,t) = bb_color{t_color_index}(2); 
        image_buffer1([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,3,t) = bb_color{t_color_index}(3); 
        image_buffer1(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],3,t) = bb_color{t_color_index}(3);         
	end
end
if Write2JPG & 0
	for i=1:frame_number
		imwrite(image_buffer1(:,:,:,i),strcat('V1_',num2str(4000+i),'.jpg'));
	end 
end
toc;
duration = toc;

% Draw VOB 2
radius = 2;
image_buffer2 = zeros(height2, width2, 3, frame_number);
Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Dataset\PET\View_007\';
%fw Images_Directory = 'C:\1Cisco\Dataset\PET\View_007\';
Image_Prefix = 'frame_';
for i = 1:frame_number
    frame_name=num2str(i-1,'%04d'); 
	frame{i} = imread(strcat(Images_Directory, Image_Prefix, frame_name, '.jpg')); 
	%frame{i} = imread(strcat(Images_Directory, Image_Prefix, num2str(4000+i-1), '.jpg'));
	image_buffer2(:,:,:,i) = uint8(frame{i});
end
image_buffer2 = uint8(image_buffer2);
for k = 1:length(VOB_2)
	t_frame_index = round( VOB_2(k).occurencehistory );
	t_bbox = round( VOB_2(k).bboxhistory );
	t_color = VOB_2(k).color;
	t_color_index = find(color_index_pool==t_color);
	for r = 1:length(t_frame_index)   
        t = t_frame_index(r);
        itop = max(t_bbox(r,2),1+radius);
        ibottom = min(t_bbox(r,4),height2-radius);
        ileft = max(t_bbox(r,1),1+radius);
        iright = min(t_bbox(r,3),width2-radius);
        image_buffer2([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,1,t) = bb_color{t_color_index}(1); 
        image_buffer2(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],1,t) = bb_color{t_color_index}(1); 
        image_buffer2([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,2,t) = bb_color{t_color_index}(2); 
        image_buffer2(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],2,t) = bb_color{t_color_index}(2); 
        image_buffer2([itop-radius:itop+radius ibottom-radius:ibottom+radius],ileft:iright,3,t) = bb_color{t_color_index}(3); 
        image_buffer2(itop:ibottom,[ileft-radius:ileft+radius iright-radius:iright+radius],3,t) = bb_color{t_color_index}(3);         
	end
end
if Write2JPG & 0
	for i=1:frame_number
		imwrite(image_buffer2(:,:,:,i),strcat('V7_',num2str(4000+i),'.jpg'));
	end 
end

if Write2MP4 | 1
	output_video_file_name = 'Cross_View_7_1';
	video_buffer = zeros(max(height1,height2),width1+width2,3,frame_number);
	video_buffer(:,1:width1,:,:) = image_buffer1;
	video_buffer(:,1+width1:width1+width2,:,:) = image_buffer2;
	video_buffer = uint8(video_buffer);
	myObj = VideoWriter(strcat(output_video_file_name,'.mp4'),'MPEG-4');
	myObj.FrameRate = 10;
	writerObj.FrameRate = 1;
	open(myObj);
	for i=1:frame_number
		writeVideo(myObj,video_buffer(:,:,:,i));
	end 
	close(myObj);
	
	for i=1:frame_number
		imwrite(video_buffer(:,:,:,i),strcat('Cross_View_',num2str(4000+i),'.jpg'));
	end
end

if IsDebugging && 0
	figure;
	for i = 1:length(color_label_merge_lookup)
		if color_label_merge_lookup(i,1)==21
			subplot(length(color_label_merge_lookup),2,i*2-1); imshow(VOB_2(color_label_merge_lookup(i,2)).image,[]);
			subplot(length(color_label_merge_lookup),2,i*2); imshow(VOB_1(color_label_merge_lookup(i,3)).image,[]);
		else %12
			subplot(length(color_label_merge_lookup),2,i*2-1); imshow(VOB_1(color_label_merge_lookup(i,2)).image,[]);
			subplot(length(color_label_merge_lookup),2,i*2); imshow(VOB_2(color_label_merge_lookup(i,3)).image,[]);	
		end
	end
end