clear;clc;close all;

show_direct_match=1;
show_feet_on_background=1;
homography_by_feet_or_feature_0_1=0;
show_local_feature=1;
show_warp=1;

%%%% Show global feature points
Images_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Multiview\'; 
bg1 = imread(strcat(Images_Directory, 'bg1.jpg'));
bg2 = imread(strcat(Images_Directory, 'bg2.jpg'));
I1=rgb2gray(bg1);
I2=rgb2gray(bg2);
% match based on global feature points (totally fail)
if show_direct_match
	points1 = detectSURFFeatures(I1);
	points2 = detectSURFFeatures(I2);
	figure; showMatchedFeatures(I1,I2,points1,points2(1:444));
	%figure; showMatchedFeatures(I1,I1,points1,points1);
	%figure; showMatchedFeatures(I2,I2,points2,points2);
end

%%%% Read feet location
Info_Directory = 'D:\Software\MATLAB\image_processing_project_fgm\1cisco\Multiview\';
frame_number=4;obj_max=2;views=2;hwsize=2;
feet=zeros(frame_number,views,obj_max,hwsize);
width=768;height=576;

for i = 1:frame_number
    for j = 1:views
        frame_name=num2str(i*10+j,'%02d'); 
        frame{i,j} = imread(strcat(Info_Directory, frame_name, '.jpg'));
        d = dir(strcat(Info_Directory, frame_name ,'_person_obj' , '*.mat'));
        [Object_number, dummy] = size(d);
        for k = 1:Object_number	% Loop thru object
            current_RCNN_mat_filename = d(k).name;
        	load(strcat(Info_Directory, current_RCNN_mat_filename));
            feet(i,j,k,:)=[floor(bbox(4)) ceil((bbox(1)+bbox(3))/2)];
        end
    end
end
% observe and manually set feets as corresponding feature points
pinfeet=[feet(1,1,1,2),feet(2,1,1,2),feet(3,1,1,2),feet(4,1,1,2);
    feet(1,1,1,1),feet(2,1,1,1),feet(3,1,1,1),feet(4,1,1,1)];
poutfeet=[feet(1,2,1,2),feet(2,2,1,2),feet(3,2,1,2),feet(4,2,1,2);
    feet(1,2,1,1),feet(2,2,1,1),feet(3,2,1,1),feet(4,2,1,1)];
%p11=feet(1,1,:,:);p12=feet(1,2,:,:);p21=feet(2,1,:,:);p22=feet(2,2,:,:);
%p31=feet(3,1,:,:);p32=feet(3,2,:,:);p41=feet(4,1,:,:);p42=feet(4,2,:,:);
% show the feet on background
if show_feet_on_background
    figure;imshow(I1);hold on;
    range=1:4;
	plot(pinfeet(1,range),pinfeet(2,range), 'r*', 'LineWidth', 2, 'MarkerSize', 15);
	figure;imshow(I2);hold on;
	plot(poutfeet(1,range),poutfeet(2,range), 'r*', 'LineWidth', 2, 'MarkerSize', 15);
end

%%%% Local feature match
obj=1;
f1=[0,0];
f2=[0,0];
bound1=30;
bound2=30;
bias=[0,35,0,-10;-10,40,10,-15;-40,50,70,30;-10,0,0,30];
imsize=0.7;
choosep=[4,1;22,3;2,8;5,3];
pinfeature=[169,432,741,261;270,390,277,213];
poutfeature=[262,52,347,436;254,323,400,254];
if show_local_feature
    figure;
end
for i = 1:frame_number
    f1(1)=feet(i,1,obj,1)+bias(i,1);f1(2)=feet(i,1,obj,2)+bias(i,2);
    f2(1)=feet(i,2,obj,1)+bias(i,3);f2(2)=feet(i,2,obj,2)+bias(i,4);
    i1=I1(max(f1(1)-bound1,1):min(f1(1)+bound1,height),max(f1(2)-bound2,1):min(f1(2)+bound2,width));
    i2=I2(max(f2(1)-bound1,1):min(f2(1)+bound1,height),max(f2(2)-bound2,1):min(f2(2)+bound2,width));
    i1=imresize(i1,imsize);
    i2=imresize(i2,imsize);
    
    points1 = detectHarrisFeatures(i1);
    points2 = detectHarrisFeatures(i2);
    if show_local_feature
        subplot(2,4,i*2-1);imshow(i1);hold on;
        plot(points1.Location(:,1),points1.Location(:,2), 'r*', 'LineWidth', 2, 'MarkerSize', 15);hold on;
        plot(points1.Location(choosep(i,1),1),points1.Location(choosep(i,1),2), '-o', 'LineWidth', 2, 'MarkerSize', 15);
        subplot(2,4,i*2);imshow(i2);hold on;
        plot(points2.Location(:,1),points2.Location(:,2), 'r*', 'LineWidth', 2, 'MarkerSize', 15);hold on;
        plot(points2.Location(choosep(i,2),1),points2.Location(choosep(i,2),2), '-o', 'LineWidth', 2, 'MarkerSize', 15);
    end
end

%%%% Show the result
% Compute homography matrix by local feature pairs
if homography_by_feet_or_feature_0_1
    pin=pinfeature.';
    pout=poutfeature.';
else
    pin=pinfeet.';
    pout=poutfeet.';
end
% warp the image
tform = fitgeotrans(pout,pin,'projective');
I2_to_I1 = imwarp(I2,tform,'OutputView',imref2d(size(I2)));
if show_warp
    figure;subplot(1,2,1);imshow(I2_to_I1);
    subplot(1,2,2);imshow(I1);
    %figure
    %imshowpair(I1,I2_to_I1)
end


